<script language="javascript">

function ListLen( list, delimiter)
{
	var listLen = 0;
	if( list.length == 0)
		return 0;

	var i;
	i = list.indexOf(delimiter);
	while( i != -1)
	{
		listLen += 1;
		i = list.indexOf(delimiter, i + 1);
	}
	
	listLen += 1;
	return listLen;
}

function ListAppend( list, element, delimiter)
{
	if (ListLen( list, delimiter) > 0)
		list += delimiter + element;
	else
		list += element;
		
	return list;
}

function ListElement( which, list, delimiter)
{
	if (which > ListLen( list, delimiter))
		return "";
	
	var cDelimit = 0;
	var charPos = 0;
	while( cDelimit < (which - 1))
	{
		charPos = list.indexOf( delimiter, charPos) + 1;
		cDelimit++;
	}
	
	if(which == ListLen( list, delimiter))
		return list.substring( charPos, list.length);
	else
		return list.substring( charPos, list.indexOf( delimiter, charPos + 1));
}

function ListFind( elem, list, delimiter)
{
	var element = "";
	element += elem;

	loc = 0;
	var i = 0;

	if(ListLen(list, delimiter) == 0)
		return 0;
	
	if(ListLen(list, delimiter) == 1)
	{
		if( list == element)	
			return 1;
		else
			return 0;
	}

	for( i=ListLen(list,delimiter); i >= 1; i--)
	{
		if (ListElement(i, list, delimiter) == element)
			loc = i;
	}

	return loc;
}
</script>