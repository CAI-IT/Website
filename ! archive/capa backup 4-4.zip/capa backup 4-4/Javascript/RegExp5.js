<script>
function RegExp(inPat) {
	//public functions
	this.exec=exec;
	this.test=test;
	this.compile=compile;
	
	//private functions
	this.GetNextToken=GetNextToken;
	this.tokenMatch=tokenMatch;
	this.rangeMatch=rangeMatch;
	this.matchRE=matchRE;
	this.accept=accept;

	//initialization
	this.compile(inPat);
	
	this.resultsArr = new Array(1);
	this.resultsArr[0] = '';
	this.resultsArrActive = new Array(1);
	this.resultsArrActive[0] = 0;
	this.archive = new Array(0);
	this.usePrev = false;
//	alert('new RegExp('+inPat+')');
}

function exec(str) {
	// compares str against this.input, tries substrings until none left
//	alert('exec('+str+')');
	var doSub;
	if(arguments.length>1 && arguments[1])
		doSub=1;
	else
		doSub=-1;
	var results=false;
	while(doSub--!=0 && !results) {
//		alert('exec call matchRE('+str+')');
		results=this.matchRE(this.GetNextToken(0),str);
//		alert('results = '+results);
		if(str.length==0 && !results)
			doSub=0;
		else
			str=str.substring(1);
	}
//	alert('exec = '+((results) ? this.resultsArr : null));
	return (results) ? this.resultsArr : null;
}

function compile(pattern) {
	this.input=pattern;
}

function GetNextToken(start) {
	var str=this.input;
	var level=1;
	if(start>=str.length) return -1;
	var c0=str.charAt(start);
	var next=0;
	var token='';
	var min=0;
	var max=0;
	var numString='';
	var numString2='';
	
//	alert('GetNextToken');

	//get token info
	if(c0=='\\') {
		c1=str.charAt(start+1);
		next=start+2;
		if(this.rangeMatch('^dDwW().',c1)==1)
			token=c1;
		else
			token=c0+c1;
	} else if(c0=='[') {
		next=str.indexOf(']',start+1)+1;
		token=str.substring(start,next);
	} else if(c0=='(') {
		level=1;
		next=start+1;
		token='(';
		while(level!=0) {
			if(str.charAt(next)=='(')
				level++;
			else if(str.charAt(next)==')')
				level--;
			token+=str.charAt(next++);
		}
	} else if(this.rangeMatch('^^$*+?|(){}',c0)) { // then it's not a special character
		token=c0;
		next=start+1;
	}

	//get loop info
	if (str.charAt(next)=='*') {min=0; max=-1; next++;}
	else if (str.charAt(next)=='+') {min=1; max=-1; next++;}
	else if (str.charAt(next)=='{') {
		var i=next+1;
		while (str.charAt(i)!=',' && str.charAt(i)!='}')	// get first number
			{numString += str.charAt(i);numString2 += str.charAt(i++);}
	 	if (str.charAt(i)==',')		// there must be 2 numbers
			{
			i++;
			numString2='';
			while (str.charAt(i)!='}')
				numString2 += str.charAt(i++);
				
			}
		next=str.indexOf('}',next+1)+1;
		min=numString.valueOf();
		if(numString2.length==0)
			max=-1;
		else
			max=numString2.valueOf();
	}
	else {min=1; max=1;}
	
	//scan through any nested ) & loop info
	while(this.rangeMatch('){*+',str.charAt(next))==1) {
		alert("Better check I'm supposed to do this...");
		if(str.charAt(next)=='{')
			next=str.indexOf('}',next+1);
		next++;
	}
//	alert('GNT='+new Array(next,token,min,max));
	return new Array(next,token,min,max);
}

function test(str) {
	//calls exec & simplifies its response to true or false
	var temp=this.exec(str);
//	alert('test:'+((temp)?true:false));
	return (temp)?true:false;
}

function matchRE(curToken,str) {
	//take the string, go through all of the tokens
	//return true (found) or false (not there)
	//testing begins with the first character only
//	alert('matchRE('+curToken+',"'+str+'")');
	
	if(curToken==-1) {
//		alert('0');
		return true;
	}
	this.usePrev=false;
	
	//break RE at ground 0 '|'s
	var level=0;
	var results=false;
	this.resultsArr=new Array(1);
	this.resultsArr[0]='';
	for(x=0; x<this.input.length; x++) {
		if(this.input.charAt(x)=='(')
			level++;
		else if(this.input.charAt(x)==')')
			level--;
		if(level==0 && this.input.charAt(x)=='|') {
			var left, right, result;
			left = new RegExp(this.input.substring(0,this.input.indexOf('|',0)));
			result = left.matchRE(left.GetNextToken(0),str);
			if(result) {
				this.resultsArr=left.resultsArr;
				return true;
			}
			right = new RegExp(this.input.substring(this.input.indexOf('|',0)+1));
			result = right.matchRE(right.GetNextToken(0),str);
			if(result) {
				this.resultsArr=right.resultsArr;
				return true;
			}
			return false;
		}
	}
	
	var pos;
	var used;
	var nextRE=new RegExp(this.input);
	var nextToken=nextRE.GetNextToken(curToken[0]);
	var againToken=new Array(curToken[0],curToken[1],curToken[2]-1,curToken[3]-1);
	var x=0;
//	alert('ag:'+againToken+'\nnxt:'+nextToken);
	
	if(againToken[2]>=0) { // under min, required
		if((used=this.tokenMatch(curToken[1],str))!=-1) { // cur matches, necessary
			if(againToken[3]!=0) { //we're still under the maximum, try again
//				alert(1);
				for(x=used;x>0;x--) // go through each substring
					if((x=this.tokenMatch(curToken[1],str.substring(0,x)))!=-1 && nextRE.matchRE(againToken,str.substring(x)))
						return this.accept(str.substring(0,x),nextRE.resultsArr,nextRE.usePrev); // it worked out
//				alert(2);
				if(againToken[2]-1>=0)
					return false;  // if we're here, we failed to find the minimum necessary
			}
			// we can fall through here if can't find another unrequired repetition
//			alert(3);
			for(x=used;x>=0;x--) // go through each substring
				if((x=this.tokenMatch(curToken[1],str.substring(0,x)))!=-1 && nextRE.matchRE(nextToken,str.substring(x)))
					return this.accept(str.substring(0,x),nextRE.resultsArr,true); // it worked out
//			alert(4);
			return false;  // if we're still here, we failed to find the minimum necessary
		} else { // cur doesn't match, fail
//			alert(5);
			return false;
		}
	} else if((used=this.tokenMatch(curToken[1],str))!=-1) { // cur matches, OK
		if(againToken[3]!=0) { //we're still under the maximum, try again
//			alert(6);
			for(x=used;x>0;x--) // go through each substring
				if((x=this.tokenMatch(curToken[1],str.substring(0,x)))!=-1 && nextRE.matchRE(againToken,str.substring(x)))
					return this.accept(str.substring(0,x),nextRE.resultsArr,nextRE.usePrev); // it worked out
			// if we're still here, couldn't find the same token again
//			alert(7);
			for(x=used;x>=0;x--) // go through each substring
				if((x=this.tokenMatch(curToken[1],str.substring(0,x)))!=-1 && nextRE.matchRE(nextToken,str.substring(x)))
					return this.accept(str.substring(0,x),nextRE.resultsArr,true); // it worked out
//			alert(8);
			return false; // if we're still here we couldn't find either of them
		} else { // maxed out: we use the next one
//			alert(9);
			for(x=used;x>=0;x--) // go through each substring
				if((x=this.tokenMatch(curToken[1],str.substring(0,x)))!=-1 && nextRE.matchRE(nextToken,str.substring(x)))
					return this.accept(str.substring(0,x),nextRE.resultsArr,true); // it worked out
//			alert(10);
			return false; // if we're still here, we couldn't find the next token
		}
	} else { // cur doesn't match, still OK since min is satisfied
//		alert(11);
		//return if the results of the next worked
		this.usePrev=true;
		return nextRE.matchRE(nextToken,str) ? this.accept('',nextRE.resultsArr,this.archive) : false;
	}

	alert('very very bad');
	return true;
}

function accept(used,rest,useArc) {
//	alert('accept('+used+' , '+rest+' , '+useArc+')');
//	alert('before this.resultsArr:'+this.resultsArr);
	this.resultsArr[0]+=used+rest[0];
	if(useArc)
		for(var i in this.archive)
			this.resultsArr[this.resultsArr.length]=this.archive[i];
	for(var i=1; i<rest.length; i++)
		this.resultsArr[this.resultsArr.length]=rest[i];
//	alert('after this.resultsArr:'+this.resultsArr);
	return true;
}


function tokenMatch(token,str) {
	// returns the number of character matched by the token (handles (..))
//	alert('tokenMatch('+token+','+str+')');

	this.archive=new Array(0);
	if(token=='undefined' || token=='-1') {return -1;}

	if(token.charAt(0)=='(' && token.length>1) {
		var check=new RegExp(token.substring(1,token.length-1));
		if(check.matchRE(check.GetNextToken(0),str)) {
//			alert(token+'\narc before:'+this.archive);
			this.archive=check.resultsArr;
//			alert(token+'\narc after:'+this.archive);
			return check.resultsArr[0].length;
		} else
			return -1;
	}

	var c=str.charAt(0);
	if(c.length==0)
		return -1;
		
	if(token=='\\w') return this.rangeMatch('[a-zA-Z0-9_]',c);
	else if(token=='\\W') return this.rangeMatch('[^a-zA-Z0-9_]',c);
	else if(token=='\\d') return this.rangeMatch('[0-9]',c);
	else if(token=='\\D') return this.rangeMatch('[^0-9]',c);
	else if(token=='\\(') return this.rangeMatch('[(]',c);
	else if(token=='\\)') return this.rangeMatch('[)]',c);
	else if(token=='\\.') return this.rangeMatch('[.]',c);
	else if(token=='.') return this.rangeMatch('[^]',c);
	else return this.rangeMatch(token,c); //either a range or simple character
}

function rangeMatch(rng, c) {
	//returns whether or not c is within rng

//	alert('rM('+rng+','+c+')');
	var ans;
	var i=0;
	if(rng.charAt(i)=='[') i++;
	if(rng.charAt(i)=='^') {ans=-1; i++;} else ans=1;
	i--;
	while(rng.charAt(++i)!=']' && i<rng.length) {
		if(rng.charAt(i)=='\\') i++;
		if(rng.charAt(i)==c) return ans;
		if(rng.charAt(i+1)=='-') {
			if(c>=rng.charAt(i) && c<=rng.charAt(i+2)) return ans;
			else i+=2;
		}
	}
	return -ans;
}
</script>