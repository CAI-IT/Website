var hostroot;
var stringroot = location.href;
stringroot = stringroot.substr(8,13);
stringroot = stringroot.toUpperCase();
if (stringroot == "TERMINALSERVER")
{
	hostroot = "https://TERMINALSERVER/Intranet/"
}
else
{
	hostroot = "https://www.jccap.org/Intranet/"
}

var isDOM=document.getElementById?1:0;
var isIE=document.all?1:0;
var isNS4=navigator.appName=='Netscape'&&!isDOM?1:0;
var isIE4=isIE&&!isDOM?1:0;
var isOp=window.opera?1:0;
var isDyn=isDOM||isIE||isNS4;

function getRef(id, par)
{
 par=!par?document:(par.navigator?par.document:par);
 return (isIE ? par.all[id] :
  (isDOM ? (par.getElementById?par:par.ownerDocument).getElementById(id) :
  (isNS4 ? par.layers[id] : null)));
}

function getSty(id, par)
{
 var r=getRef(id, par);
 return r?(isNS4?r:r.style):null;
}

if (!window.LayerObj) var LayerObj = new Function('id', 'par',
 'this.ref=getRef(id, par); this.sty=getSty(id, par); return this');
function getLyr(id, par) { return new LayerObj(id, par) }

function LyrFn(fn, fc)
{
 LayerObj.prototype[fn] = new Function('var a=arguments,p=a[0],px=isNS4||isOp?0:"px"; ' +
  'with (this) { '+fc+' }');
}
LyrFn('x','if (!isNaN(p)) sty.left=p+px; else return parseInt(sty.left)');
LyrFn('y','if (!isNaN(p)) sty.top=p+px; else return parseInt(sty.top)');
LyrFn('vis','sty.visibility=p');
LyrFn('bgColor','if (isNS4) sty.bgColor=p?p:null; ' +
 'else sty.background=p?p:"transparent"');
LyrFn('bgImage','if (isNS4) sty.background.src=p?p:null; ' +
 'else sty.background=p?"url("+p+")":"transparent"');
LyrFn('clip','if (isNS4) with(sty.clip){left=a[0];top=a[1];right=a[2];bottom=a[3]} ' +
 'else sty.clip="rect("+a[1]+"px "+a[2]+"px "+a[3]+"px "+a[0]+"px)" ');
LyrFn('write','if (isNS4) with (ref.document){write(p);close()} else ref.innerHTML=p');
LyrFn('alpha','var f=ref.filters,d=(p==null); if (f) {' +
 'if (!d&&sty.filter.indexOf("alpha")==-1) sty.filter+=" alpha(opacity="+p+")"; ' +
 'else if (f.length&&f.alpha) with(f.alpha){if(d)enabled=false;else{opacity=p;enabled=true}} }' +
 'else if (isDOM) sty.MozOpacity=d?"":p+"%"');

function setLyr(lVis, docW, par)
{
 if (!setLyr.seq) setLyr.seq=0;
 if (!docW) docW=0;
 var obj = (!par ? (isNS4 ? window : document.body) :
  (!isNS4 && par.navigator ? par.document.body : par));
 var oIA=obj.insertAdjacentHTML, oAC=obj.appendChild, newID='_js_layer_'+setLyr.seq++;

 if (oIA) oIA('beforeEnd', '<div id="'+newID+'" style="position:absolute"></div>');
 else if (oAC)
 {
  var newL=document.createElement('div');
  oAC(newL); newL.id=newID; newL.style.position='absolute';
 }
 else if (isNS4)
 {
  var newL=new Layer(docW, obj);
  newID=newL.id;
 }

 var lObj=getLyr(newID, par);
 with (lObj) if (ref) { vis(lVis); x(0); y(0); sty.width=docW+(isNS4?0:'px') }
 return lObj;
}

var CSSmode=document.compatMode;
CSSmode=(CSSmode&&CSSmode.indexOf('CSS')!=-1)||isDOM&&!isIE||isOp?1:0;

if (!window.page) var page = { win: window, minW: 0, minH: 0, MS: isIE&&!isOp,
 db: CSSmode?'documentElement':'body' }

page.winW=function()
 { with (this) return Math.max(minW, MS?win.document[db].clientWidth:win.innerWidth) }
page.winH=function()
 { with (this) return Math.max(minH, MS?win.document[db].clientHeight:win.innerHeight) }

page.scrollX=function()
 { with (this) return MS?win.document[db].scrollLeft:win.pageXOffset }
page.scrollY=function()
 { with (this) return MS?win.document[db].scrollTop:win.pageYOffset }

function popOver(mN, iN) { with (this)
{
 clearTimeout(hideTimer);
 overM = mN;
 overI = iN;
 if (iN && this.onmouseover) onmouseover(mN, iN);

 litOld = litNow;
 litNow = new Array();
 var litM = mN, litI = iN;
 while(1)
 {
  litNow[litM] = litI;
  if (litM == 'root') break;
  litI = menu[litM][0].parentItem;
  litM = menu[litM][0].parentMenu;
 }

 var same = true;
 for (var z in menu) if (litNow[z] != litOld[z]) same = false;
 if (same) return;

 clearTimeout(showTimer);

 for (thisM in menu) with (menu[thisM][0])
 {
  if (!lyr) continue;

  litI = litNow[thisM];
  oldI = litOld[thisM];

  if (litI && (litI != oldI)) changeCol(thisM, litI, true);

  if (oldI && (oldI != litI)) changeCol(thisM, oldI, false);

  if (litI && !visNow && (thisM != 'root'))
  {
   showMenu(thisM);
   visNow = true;
  }

  if (isNaN(litI) && visNow)
  {
   hideMenu(thisM);
   visNow = false;
  }
 }

 nextMenu = '';
 if ((menu[mN][iN].type == 'sm:') && !menu[mN][0].subsOnClick)
 {
  var targ = menu[mN][iN].href, lyrM = menu[mN][0].lyr;

  var showStr = 'with ('+myName+') { menu.'+targ+'[0].visNow = true; ' +
   'position("'+targ+'"); showMenu("'+targ+'") }';
  nextMenu = targ;
  if (showDelay) showTimer = setTimeout(showStr, showDelay);
  else eval(showStr);
 }
}}

function popOut(mN, iN) { with (this)
{
 if ((mN != overM) || (iN != overI)) return;

 if (this.onmouseout) onmouseout(mN, iN);

 var thisI = menu[mN][iN];

 if (thisI.href != nextMenu)
 {
  clearTimeout(showTimer);
  nextMenu = '';
 }

 if (hideDelay)
 {
  var delay = ((mN == 'root') && (thisI.type != 'sm:')) ? 50 : hideDelay;
  hideTimer = setTimeout(myName + '.over("root", 0)', delay);
 }

 overM = 'root';
 overI = 0;
}}

function popClick(mN, iN) { with (this)
{
 if (this.onclick) onclick(mN, iN);

 var thisI = menu[mN][iN], hideM = true;

 with (thisI) switch (type)
 {
  case 'sm:':
  {
   if (menu[overM][0].subsOnClick)
   {
    menu[href][0].visNow = true;
    position(href);
    showMenu(href);
    hideM = false;
   }
   break;
  }
  case 'js:': { eval(href); break }
  case '': type = 'window';
  default: if (href) eval(type + '.location.href = "' + href + '"');
 }

 if (hideM) over('root', 0);
}}

function popChangeCol(mN, iN, isOver) { with (this.menu[mN][iN])
{
 if (!lyr || !lyr.ref) return;

 var col = isOver?overCol:outCol;
 var bgFn = (col.indexOf('.')==-1) ? 'bgColor' : 'bgImage';
 if (isNS4) lyr[bgFn](col);

 if ((overClass != outClass) || (outBorder != overBorder)) with (lyr)
 {
  if (isNS4) write(this.getHTML(mN, iN, isOver));
  else
  {
   ref.className = (isOver ? overBorder : outBorder);
   var chl = (isDOM ? ref.childNodes : ref.children)
   if (chl) for (var i = 0; i < chl.length; i++) chl[i].className = isOver?overClass:outClass;
  }
 }

 if (!isNS4) lyr[bgFn](col);

 if (outAlpha != overAlpha) lyr.alpha(isOver ? overAlpha : outAlpha);
}}

function popPosition(posMN) { with (this)
{
 for (mN in menu)
 {
  if (posMN && (posMN != mN)) continue;
  with (menu[mN][0])
  {
   if (!lyr || !lyr.ref || !visNow) continue;

   var pM, pI, newX = eval(offX), newY = eval(offY);
   if (mN != 'root')
   {
    pM = menu[parentMenu];
    pI = pM[parentItem].lyr;
    if (!pI) continue;
   }

   var eP = eval(par);
   var pW = (eP && eP.navigator ? eP : window);

   with (pW.page) var sX=scrollX(), wX=sX+winW(), sY=scrollY(), wY=winH()+sY;
   wX = isNaN(wX)||!wX ? 9999 : wX;
   wY = isNaN(wY)||!wY ? 9999 : wY;

   if (pM && typeof(offX)=='number') newX = Math.max(sX,
    Math.min(newX+pM[0].lyr.x()+pI.x(), wX-menuW-(isIE?5:20)));
   if (pM && typeof(offY)=='number') newY = Math.max(sY,
    Math.min(newY+pM[0].lyr.y()+pI.y(), wY-menuH-(isIE?5:20)));

   lyr.x(newX);
   lyr.y(newY);
  }
 }
}}

function addProps(obj, data, names, addNull)
{
 for (var i = 0; i < names.length; i++) if(i < data.length || addNull) obj[names[i]] = data[i];
}

function ItemStyle()
{
 var names = ['len', 'spacing', 'popInd', 'popPos', 'pad', 'outCol', 'overCol', 'outClass',
  'overClass', 'outBorder', 'overBorder', 'outAlpha', 'overAlpha', 'normCursor', 'nullCursor'];
 addProps(this, arguments, names, true);
}

function popStartMenu(mName) { with (this)
{
 if (!menu[mName]) { menu[mName] = new Array(); menu[mName][0] = new Object(); }

 actMenu = menu[mName];
 aM = actMenu[0];
 actMenu.length = 1;

 var names = ['isVert', 'isVert', 'offX','offY', 'width', 'itemSty', 'par',
  'parentMenu', 'parentItem', 'visNow', 'oncreate', 'subsOnClick'];
 addProps(aM, arguments, names, true);

 aM.extraHTML = '';
 aM.menuW = aM.menuH = 0;

 if (!aM.lyr) aM.lyr = null;

 if (mName == 'root') menu.root[0].oncreate = new Function('this.visNow=true; ' +
  myName + '.position("root"); this.lyr.vis("visible")');
}}

function popAddItem() { with (this) with (actMenu[0])
{
 var aI = actMenu[actMenu.length] = new Object();

 var names = ['text', 'href', 'type', 'itemSty', 'len', 'spacing', 'popInd', 'popPos',
  'pad', 'outCol', 'overCol', 'outClass', 'overClass', 'outBorder', 'overBorder',
  'outAlpha', 'overAlpha', 'normCursor', 'nullCursor',
  'iX', 'iY', 'iW', 'iH', 'lyr'];
 addProps(aI, arguments, names, true);

 var iSty = (arguments[3] ? arguments[3] : actMenu[0].itemSty);
 for (prop in iSty) if (aI[prop]+'' == 'undefined') aI[prop] = iSty[prop];

 if (aI.outBorder)
 {
  if (isNS4) aI.pad++;
 }

 aI.iW = (isVert ? width : aI.len);
 aI.iH = (isVert ? aI.len : width);

 var lastGap = (actMenu.length > 2) ? actMenu[actMenu.length - 2].spacing : 0;

 var spc = ((actMenu.length > 2) && aI.outBorder ? 1 : 0);

 if (isVert)
 {
  menuH += lastGap - spc;
  aI.iX = 0; aI.iY = menuH;
  menuW = width; menuH += aI.iH;
 }
 else
 {
  menuW += lastGap - spc;
  aI.iX = menuW; aI.iY = 0;
  menuW += aI.iW; menuH = width;
 }

 if (aI.outBorder && CSSmode)
 {
  aI.iW -= 2;
  aI.iH -= 2;
 }
}}

function popGetHTML(mN, iN, isOver) { with (this)
{
 var itemStr = '';
 with (menu[mN][iN])
 {
  var textClass = (isOver ? overClass : outClass);

  if ((type == 'sm:') && popInd)
  {
   if (isNS4) itemStr += '<layer class="' + textClass + '" left="'+ ((popPos+iW)%iW) +
    '" top="' + pad + '" height="' + (iH-2*pad) + '">' + popInd + '</layer>';
   else itemStr += '<div class="' + textClass + '" style="position: absolute; left: ' +
    ((popPos+iW)%iW) + 'px; top: ' + pad + 'px; height: ' + (iH-2*pad) + 'px">' + popInd + '</div>';
  }

  if (isNS4) itemStr += (outBorder ? '<span class="' + (isOver?overBorder:outBorder) +
   '"><spacer type="block" width="' + (iW-8) + '" height="' + (iH-8) + '"></span>' : '') +
   '<layer left="' + pad + '" top="' + pad + '" width="' + (iW-2*pad) + '" height="' +
   (iH-2*pad) + '"><a class="' + textClass + '" href="#" ' +
   'onClick="return false" onMouseOver="status=\'\'; ' + myName + '.over(\'' + mN + '\',' +
   iN + '); return true">' + text + '</a></layer>';

  else itemStr += '<div class="' + textClass + '" style="position: absolute; left: ' + pad +
   'px; top: ' + pad + 'px; width: ' + (iW-2*pad) + 'px; height: ' + (iH-2*pad) + 'px">' +
   text + '</div>';
 }
 return itemStr;
}}

function popUpdate(docWrite, upMN) { with (this)
{
 if (!isDyn) return;

 for (mN in menu) with (menu[mN][0])
 {
  if (upMN && (upMN != mN)) continue;

  var str = '';

  for (var iN = 1; iN < menu[mN].length; iN++) with (menu[mN][iN])
  {
   var itemID = myName + '_' + mN + '_' + iN;

   var targM = menu[href];
   if (targM && (type == 'sm:'))
   {
    targM[0].parentMenu = mN;
    targM[0].parentItem = iN;
   }

   var isImg = (outCol.indexOf('.') != -1) ? true : false;

   if (!isIE && normCursor=='hand') normCursor = 'pointer';

   if (isDOM || isIE4)
   {
    str += '<div id="' + itemID + '" ' + (outBorder ? 'class="'+outBorder+'" ' : '') +
     'style="position: absolute; left: ' + iX + 'px; top: ' + iY + 'px; width: ' + iW +
     'px; height: ' + iH + 'px; z-index: 1000; background: ' + (isImg?'url('+outCol+')':outCol) +
     ((typeof(outAlpha)=='number') ? '; filter: alpha(opacity='+ outAlpha + '); -moz-opacity: ' +
      (outAlpha/100) : '') +
     '; cursor: ' + ((type!='sm:' && href) ? normCursor : nullCursor) + '" ';
   }
   else if (isNS4)
   {
    str += '<layer id="' + itemID + '" left="' + iX + '" top="' + iY + '" width="' +
     iW + '" height="' + iH + '" z-index="1000" ' +
     (outCol ? (isImg ? 'background="' : 'bgcolor="') + outCol + '" ' : '');
   }

   var evtMN = '(\'' + mN + '\',' + iN + ')"';
   str += 'onMouseOver="' + myName + '.over' + evtMN +
     ' onMouseOut="' + myName + '.out' + evtMN +
     ' onClick="' + myName + '.click' + evtMN + '>' +
     getHTML(mN, iN, false) + (isNS4 ? '</layer>' : '</div>');

  }

  var eP = eval(par);

  setTimeout(myName + '.setupRef(' + docWrite + ', "' + mN + '")', 50);

  var mVis = visNow ? 'visible' : 'hidden';

  if (docWrite)
  {
   var targFr = (eP && eP.navigator ? eP : window);
   targFr.document.write('<div id="' + myName + '_' + mN + '_Div" style="position: absolute; ' +
    'visibility: ' + mVis + '; left: 0px; top: 0px; width: ' + (menuW+2) + 'px; height: ' +
    (menuH+2) + 'px; z-index: 1000">' + str + extraHTML + '</div>');
  }
  else
  {
   if (!lyr || !lyr.ref) lyr = setLyr(mVis, menuW, eP);
   else if (isIE4) setTimeout(myName + '.menu.' + mN + '[0].lyr.sty.width=' + (menuW+2), 50);

   with (lyr) { sty.zIndex = 1000; write(str + extraHTML) }
  }

 }
}}

function popSetupRef(docWrite, mN) { with (this) with (menu[mN][0])
{
 if (docWrite || !lyr || !lyr.ref) lyr = getLyr(myName + '_' + mN + '_Div', eval(par));

 for (var i = 1; i < menu[mN].length; i++)
  menu[mN][i].lyr = getLyr(myName + '_' + mN + '_' + i, (isNS4?lyr.ref:eval(par)));

 if (menu[mN][0].oncreate) oncreate();
}}

function PopupMenu(myName)
{
 this.myName = myName;

 this.showTimer = 0;
 this.hideTimer = 0;
 this.showDelay = 0;
 this.hideDelay = 500;
 this.showMenu = '';

 this.menu =  new Array();
 this.litNow = new Array();
 this.litOld = new Array();

 this.overM = 'root';
 this.overI = 0;

 this.actMenu = null;

 this.over = popOver;
 this.out = popOut;
 this.changeCol = popChangeCol;
 this.position = popPosition;
 this.click = popClick;
 this.startMenu = popStartMenu;
 this.addItem = popAddItem;
 this.getHTML = popGetHTML;
 this.update = popUpdate;
 this.setupRef = popSetupRef;

 this.showMenu = new Function('mName', 'this.menu[mName][0].lyr.vis("visible")');
 this.hideMenu = new Function('mName', 'this.menu[mName][0].lyr.vis("hidden")');
}








// *** START EDITING HERE ***

var hBar = new ItemStyle(40, 10, '', 0, 0, '#336699', '#336699', 'highText', 'highText', '', '',
 null, null, 'hand', 'default');

var subM = new ItemStyle(22, 0, '&gt;', -15, 3, '#333366', '#990033', 'lowText', 'highText',
 'itemBorder', 'itemBorder', null, null, 'hand', 'default');

var subBlank = new ItemStyle(22, 1, '&gt;', -15, 3, '#CCCCDD', '#6699CC', 'lowText', 'highText',
 'itemBorderBlank', 'itemBorder', null, null, 'hand', 'default');

var button = new ItemStyle(22, 1, '&gt;', -15, 2, '#006633', '#CC6600', 'buttonText', 'buttonHover',
 'buttonBorder', 'buttonBorderOver', 80, 95, 'crosshair', 'default');




var pMenu = new PopupMenu('pMenu');
with (pMenu)
{
//The following variable defines a default window for use in a window.open script
//Syntax:  window.open("hyperlink", "Title(Optional)", defWindow)
var screenWidth = screen.width
var screenHeight = screen.height

w = screen.width;
h = screen.height;
aw = w - 8;
ah = h - 150;

if (screenWidth > 1000 )
{
     var defWindow="status=yes,scrollbars=yes,resizable=yes,toolbar=yes, menubar=yes, height=570,width=1010,left=0,top=0";
     //var defWindow2="maximize=yes',status=yes,scrollbars=yes,resizable=yes,toolbar=no, menubar=yes, height=570,width=1010,left=0,top=0";
     
}
else
{
     var defWindow="status=yes,scrollbars=yes,resizable=yes,toolbar=yes, menubar=yes, height=480,width=700,left=80,top=80";
     
}
     var defWindow2="maximize=yes',status=yes,scrollbars=yes,resizable=yes,toolbar=no, menubar=yes,width=" + aw + ",height= " + ah + ",left=0,top=0";
var folderWindow="scrollbars=yes,resizable=yes,menubar=yes, height=400,width=700,left=80,top=80";

// Begin ROOT Menu
//
startMenu('root', false, 47, 0, 20, hBar, 'topFr');
addItem('<br>Home', 'index.asp', 'botFr', hBar, 45);
addItem('<br>Company Information', 'mCompInfo', 'sm:', hBar, 80);
addItem('<br>Company Documents', 'mCompDocs', 'sm:', hBar, 70);
addItem('<br>Policy Manuals', 'mManuals', 'sm:', hBar, 60);
addItem('<br>Samples', 'mSamples', 'sm:', hBar, 60);
addItem('<br>Restricted Access', 'mRestricted', 'sm:', hBar, 70);
addItem('<br>Bulletin Boards', 'mBoards', 'sm:', hBar, 50);
addItem('<br>News', 'mNews', 'sm:', hBar, 45);
addItem('<br>Website', 'window.open("http://www.jccap.org/newer/default.asp", "", defWindow)', 'js:', hBar, 50);

addItem('<br>Help', 'mHelp', 'sm:', hBar, 40);
//
//End ROOT Menu

//Begin Company Information Menu
//
startMenu('mCompInfo', true, 0, 'botFr.page.scrollY()+2', 170, subM, 'botFr');
addItem('&nbsp; &nbsp; Annual Report', 'mAnnualReport', 'sm:');
addItem('&nbsp; &nbsp; Holiday Schedule', 'CompanyDocuments/holidaySchedule.asp', 'botFr');
addItem('&nbsp; &nbsp; Hospitalization Rates', 'CompanyDocuments/HospitalizationRates - 20030101.asp', 'botFr');
addItem('&nbsp; &nbsp; Job Announcements', 'mJobPost', 'sm:');
addItem('&nbsp; &nbsp; Job Descriptions', 'mJobDesc', 'sm:');
addItem('&nbsp; &nbsp; Job Evaluations', 'mJobEval', 'sm:');
addItem('&nbsp; &nbsp; Organizational Chart', 'window.open("OrganizationalChart/orgChart.htm", "", defWindow)', 'js:');
addItem('&nbsp; &nbsp; Phone Extensions', 'CompanyDocuments/PhoneExtList.asp', 'botFr');
addItem('&nbsp; &nbsp; Poverty Income Guidelines', 'window.open("CompanyDocuments/Poverty Income Guidelines 2003.xls", "", defWindow)', 'js:');
//addItem('&nbsp; &nbsp; Staff Phone Directory', 'CompanyDocuments/HomePhoneList.asp', 'botFr');
addItem('&nbsp; &nbsp; Printable Calendar', 'window.open("http://www.timeanddate.com/calendar/", "", defWindow)', 'js:');
addItem('&nbsp; &nbsp; Staff Meeting Minutes', 'mStaffMin', 'sm:');
addItem('&nbsp; &nbsp; Wage Sheet', 'window.open("CompanyDocuments/WageScale.xls", "", defWindow)', 'js:');

//Annual Report Sub Menu
startMenu('mAnnualReport', true, 172, 0, 190, subM, 'botFr');
addItem('&nbsp; &nbsp; 2000 - 2001 Annual Report', 'CompanyDocuments/annualReport.asp', 'botFr');
addItem('&nbsp; &nbsp; 2001 - 2002 Annual Report', 'window.open("CompanyDocuments/2002annualReport.pdf", "", defWindow2)', 'js:');


//Job Description Sub Menu
startMenu('mJobDesc', true, 172, 0, 180, subM, 'botFr');
addItem('Add a New Position', 'window.open("Job_Descriptions/WebPages/MaintainPositions.asp", "", defWindow2)', 'js:');
addItem('Create a Job Description', 'window.open("Job_Descriptions/WebPages/jobDescriptionDefault.asp", "", defWindow2)', 'js:');
addItem('Edit a Job Description', 'window.open("Job_Descriptions/WebPages/jobDescriptionSelect.asp?revise=0", "", defWindow2)', 'js:');
addItem('Job Description Checklist', 'Job_Descriptions/WebPages/jobDescriptionChecklist.asp', 'botFr');
//addItem('Job Description Codes', 'Job_Descriptions/WebPages/jobDescriptionCodes.asp', 'botFr');
addItem('Revise a Job Description', 'window.open("Job_Descriptions/WebPages/jobDescriptionSelect.asp?revise=1", "", defWindow2)', 'js:');
addItem('View Current Job Descriptions', 'Job_Descriptions/WebPages/jobDescriptionList.asp', 'botFr');

//Job Evaluation Sub Menu
startMenu('mJobEval', true, 172, 0, 190, subM, 'botFr');
addItem('Administrate Job Evaluations', 'window.open("Job_Evaluations/WebPages/jobEvaluationSelectAdmin.asp", "", defWindow2)', 'js:');
addItem('Conduct a Job Evaluation', 'window.open("Job_Evaluations/WebPages/jobEvaluationDefault.asp", "", defWindow2)', 'js:');
addItem('Conduct a Self Evaluation', 'window.open("Job_Evaluations/WebPages/jobEvaluationDefault.asp?self=1", "", defWindow2)', 'js:');
addItem('Edit a Job/Self Evaluation', 'window.open("Job_Evaluations/WebPages/jobEvaluationSelect.asp", "", defWindow2)', 'js:');
addItem('Evaluation Rating Criteria', 'window.open("Job_Evaluations/WebPages/jobEvaluationCriteria.asp", "", defWindow2)', 'js:');
addItem('View Completed Evaluations', 'window.open("Job_Evaluations/WebPages/jobEvaluationUserListing.asp", "", defWindow2)', 'js:');
addItem('View Evaluation Schedule', 'window.open("Job_Evaluations/WebPages/jobEvaluationList.asp", "", defWindow2)', 'js:');
//End Job Evaluation Sub Menu

//Job Posting Sub Menu
startMenu('mJobPost', true, 172, 0, 190, subM, 'botFr');
addItem('Create a Job Announcement', 'window.open("Job_Postings/WebPages/JobPostingform.asp", "", defWindow2)', 'js:');
addItem('Maintain Job Announcements', 'window.open("Job_Postings/WebPages/JobPostingSelect.asp", "", defWindow2)', 'js:');
//End Job Posting Sub Menu

//Staff Meeting Minutes Sub Menu
startMenu('mStaffMin', true, 172, 0, 110, subM, 'botFr');
addItem('2003 Meetings', 'mStaff2003', 'sm:');
addItem('2002 Meetings', 'mStaff2002', 'sm:');
//End Staff Meeting Minutes Sub


//Staff Meeting Minutes (2002) Sub Menu
startMenu('mStaff2002', true, 112, 0, 180, subM, 'botFr');
addItem('January 2002', 'window.open("StaffMeetingMinutes/January2002.doc", "", defWindow)', 'js:');
addItem('February 2002', 'window.open("StaffMeetingMinutes/February2002.doc", "", defWindow)', 'js:');
addItem('March 2002 (canceled)');
addItem('April 2002', 'window.open("StaffMeetingMinutes/April2002.doc", "", defWindow)', 'js:');
addItem('May 2002 (canceled)');
addItem('June 2002', 'window.open("StaffMeetingMinutes/June2002.doc", "", defWindow)', 'js:');
addItem('July 2002', 'window.open("StaffMeetingMinutes/July2002.doc", "", defWindow)', 'js:');
addItem('August 2002', 'window.open("StaffMeetingMinutes/August2002.doc", "", defWindow)', 'js:');
addItem('September 2002 (canceled)');
addItem('October 2002', 'window.open("StaffMeetingMinutes/October2002.doc", "", defWindow)', 'js:');
addItem('November 2002', 'window.open("StaffMeetingMinutes/November2002.doc", "", defWindow)', 'js:');
addItem('December 2002', 'window.open("StaffMeetingMinutes/December2002.doc", "", defWindow)', 'js:');
//End Staff Meeting (2002) Minutes Sub


//Staff Meeting Minutes (2003) Sub Menu
startMenu('mStaff2003', true, 112, 0, 180, subM, 'botFr');
addItem('January 2003', 'window.open("StaffMeetingMinutes/January2003.doc", "", defWindow)', 'js:');
addItem('February 2003', 'window.open("StaffMeetingMinutes/February2003.doc", "", defWindow)', 'js:');
addItem('March 2003', 'window.open("StaffMeetingMinutes/March2003.doc", "", defWindow)', 'js:');
addItem('April 2003 (canceled)');
addItem('May 2003 (in progress)');
addItem('June 2003 (canceled)');
addItem('July 2003 (in progress)');
addItem('August 2003 (in progress)');
addItem('September 2003 (canceled)');
//End Staff Meeting (2003) Minutes Sub
//
//End Company Information Menu

//Begin Company Documents Menu
//
startMenu('mCompDocs', true, 0, 'botFr.page.scrollY()+2', 150, subM, 'botFr');
addItem('&nbsp; &nbsp; Agency Forms', 'mForms', 'sm:');
addItem('&nbsp; &nbsp; Board Documents', 'mBoardDocs', 'sm:');
addItem('&nbsp; &nbsp; Contract Narratives', 'Under-Construction.asp', 'botFr');
//
//Agency Forms Sub Menu
startMenu('mForms', true, 152, 0, 120, subM, 'botFr');
addItem('Enter a new Form', 'window.open("Agency_Forms/WebPages/FormUpload.asp", "", defWindow2)', 'js:');
addItem('View Current Forms', 'window.open("Agency_Forms/WebPages/forms.asp", "", defWindow)', 'js:');
//Agency Forms Sub Menu
//
//Board Documents Sub Menu
startMenu('mBoardDocs', true, 152, 0, 120, subM, 'botFr');
addItem('&nbsp; &nbsp; Board Listing', 'CompanyDocuments/BoardListing/Webpages/BoardListing.asp', 'botFr');
addItem('&nbsp; &nbsp; Board Minutes', 'mBoardMinutes', 'sm:');
//End Board Documents Sub Menu
//
//Board Documents Minutes Sub Menu
startMenu('mBoardMinutes', true, 122, 0, 200, subM, 'botFr');
addItem('April 24, 2003', 'window.open("BoardMinutes/April2003.doc", "", defWindow)', 'js:');
addItem('June 19, 2003', 'window.open("BoardMinutes/June2003.doc", "", defWindow)', 'js:');
addItem('September 25, 2003', 'window.open("BoardMinutes/September2003.doc", "", defWindow)', 'js:');
addItem('November 20, 2003  (scheduled)');
//End Board Documents Minutes Sub Menu
//
//End Company Documents Menu

//Begin Policy Manuals Menu
//
startMenu('mManuals', true, 0, 'botFr.page.scrollY()+2', 100, subM, 'botFr');
addItem('&nbsp; &nbsp;Handbook', 'Under-Construction.asp', 'botFr');
addItem('&nbsp; &nbsp;Fiscal Policy', 'Under-Construction.asp', 'botFr');
//
//End Policy Manuals Menu

//Begin Samples Menu
//
startMenu('mSamples', true, 0, 'botFr.page.scrollY()+2', 130, subM, 'botFr');
addItem('&nbsp; &nbsp; Thank You Letter', 'window.open("Samples/Thank You Letter - Revised 20030110.doc", "", defWindow2)', 'js:');
addItem('&nbsp; &nbsp; Thank You Letter 2', 'window.open("Samples/Thank You Letter - Sample2.doc", "", defWindow2)', 'js:');

//
//End Samples Menu

//Begin Restricted Access Menu
//
startMenu('mRestricted', true, 0, 'botFr.page.scrollY()+2', 170, subM, 'botFr');
addItem('&nbsp; &nbsp;ACTS', 'window.open("file://Win2003server/Acts/", "", folderWindow)', 'js:');
addItem('&nbsp; &nbsp;Intranet', 'window.open("file://TerminalServer/wwwroot/Intranet/", "", folderWindow)', 'js:');
addItem('&nbsp; &nbsp;MT', 'window.open("file://Win2003server/MT/", "", folderWindow)', 'js:');
addItem('&nbsp; &nbsp;Property Inventory System', 'window.open("file://Win2003server/PROPERTY/", "", folderWindow)', 'js:');
addItem('&nbsp; &nbsp;Staff Database', 'window.open("file://TERMINALSERVER/Staff Database/Staff Database/", "", folderWindow)', 'js:');
//
//End Restricted Access Menu

//Begin Bulletin Boards Menu
//
startMenu('mBoards', true, 0, 'botFr.page.scrollY()+2', 110, subM, 'botFr');
addItem('&nbsp; &nbsp;Project Board', 'mProjectBoard', 'sm:');
addItem('&nbsp; &nbsp;Staff Board', 'mStaffBoard', 'sm:');

//PROJECT BULLETIN BOARD MENU
//Project Board Sub Menu
startMenu('mProjectBoard', true, 112, 0, 120, subM, 'botFr');
addItem('Post a Message', 'projectForm.asp', 'botFr');
addItem('View Postings', 'mProjectView', 'sm:');
addItem('Delete Messages', 'projectSelect.asp?default=1', 'botFr');
//
//Project Board View Message Sub Menu
startMenu('mProjectView', true, 122, 0, 120, subM, 'botFr');
addItem('By Date', 'projectByDate.asp', 'botFr');
addItem('By Project', 'projectByProject.asp?Project=0', 'botFr');
//
//END PROJECT BULLETIN BOARD MENU

//STAFF BULLETIN BOARD MENU
//Staff Board Sub Menu
startMenu('mStaffBoard', true, 112, 0, 120, subM, 'botFr');
addItem('Post a Message', 'boardForm.asp', 'botFr');
addItem('View Postings', 'mStaffView', 'sm:');
addItem('Delete Messages', 'boardSelect.asp', 'botFr');
//
//Staff Board View Message Sub Menu
startMenu('mStaffView', true, 122, 0, 120, subM, 'botFr');
addItem('By Date', 'boardByDate.asp', 'js:');
addItem('By Category', 'boardByCategory.asp?Cat=0', 'botFr');
//
//END STAFF BULLETIN BOARD MENU

//End Bulletin Boards Menu


//Begin News Menu
//
startMenu('mNews', true, 0, 'botFr.page.scrollY()+2', 130, subM, 'botFr');
addItem('&nbsp; &nbsp;Maintain Top 5\'s', 'window.open("NewsReleases/WebPages/NewsReleaseHome.asp", "", defWindow2)', 'js:');
addItem('&nbsp; &nbsp;News Releases', 'mNewsRelease', 'sm:');
addItem('&nbsp; &nbsp;Upcoming Events', 'mEvents', 'sm:');

//Begin News Release Menu
//
startMenu('mNewsRelease', true, 132, '23', 220, subM, 'botFr');
//addItem('&nbsp; &nbsp;Post a News Release', 'NewsReleases/WebPages/newsReleaseForm.asp', 'botFr');
addItem('Media Listing', 'CompanyDocuments/MediaList/Webpages/MediaList.asp', 'botFr');
addItem('Post a News Release', 'window.open("NewsReleases/WebPages/NewsReleaseForm.asp", "", defWindow2)', 'js:');
addItem('View/Edit/Delete a News Release', 'window.open("NewsReleases/WebPages/NewsReleaseList.asp", "", defWindow2)', 'js:');
//
//End News Release Menu

//Begin Upcoming Events Menu
//
startMenu('mEvents', true, 132, '45', 120, subM, 'botFr');
addItem('Add a new Event', 'window.open("Events/eventForm.asp", "", defWindow2)', 'js:');
addItem('Edit/Delete an Event', 'window.open("Events/eventlist.asp", "", defWindow2)', 'js:');
//
//End Upcoming Events Menu

//Begin Help Menu
//
startMenu('mHelp', true, 0, 'botFr.page.scrollY()+2', 150, subM, 'botFr');
addItem('&nbsp; &nbsp;About', 'window.open(hostroot + "about.asp", "", "scrollbars=no, status=no, menubar=no, titlebar=0,resizable=no,toolbar=no, height=425,width=550,left=80,top=80")', 'js:');
//addItem('&nbsp; &nbsp;Account Management', 'https://www.jccap.org/intranet/manageAccounts.asp', 'botFr');
addItem('&nbsp; &nbsp;Account Management', 'window.open("https://www.jccap.org/intranet/manageAccounts.asp", "", folderWindow)', 'js:');
addItem('&nbsp; &nbsp;Request Assistance', 'mailto:rcardamone@jccap.org;mmcmahan@jccap.org', '');
addItem('&nbsp; &nbsp;Staff Training', 'mStaffTraining', 'sm:');

//Staff Training Sub Menu
startMenu('mStaffTraining', true, 152, 0, 150, subM, 'botFr');
addItem('Logo Usage', 'window.open("StaffTraining/Logo.pdf", "", defWindow)', 'js:');
addItem('Mission Statement', 'window.open("http://www.jccap.org/newer/MissionStatement.asp", "", defWindow)', 'js:');
addItem('Promise Statement', 'Under-Construction.asp', 'botFr');

//
//End Help Menu
}



addMenuBorder(pMenu, window.subBlank,
 null, '#666666', 1, '#CCCCDD', 2);

addDropShadow(pMenu, window.subM,
 [40,"#333333",6,6,-4,-4], [40,"#666666",4,4,0,0]);
addDropShadow(pMenu, window.subBlank,
 [40,"#333333",6,6,-4,-4], [40,"#666666",4,4,0,0]);


if (!isOp && navigator.userAgent.indexOf('rv:0.')==-1)
{
 pMenu.showMenu = new Function('mN','menuAnim(this, mN, 100)');
 pMenu.hideMenu = new Function('mN','menuAnim(this, mN, -100)');
}



// There's no "events" section here now, remember that's handled by the SUBFR.JS file.




function menuAnim(menuObj, menuName, dir)
{
 var mD = menuObj.menu[menuName][0];
 if (!mD.timer) mD.timer = 0;
 if (!mD.counter) mD.counter = 0;
 with (mD)
 {
  clearTimeout(timer);
  if (!lyr || !lyr.ref) return;
  if (dir>0) lyr.vis('visible');
  lyr.sty.zIndex = 1001 + dir;

  lyr.clip(0, 0, menuW+2, (menuH+2)*Math.pow(Math.sin(Math.PI*counter/200),0.75) );
  if ((isDOM&&!isIE) && (counter>=100)) lyr.sty.clip='';

  counter += dir;
  if (counter>100) counter = 100;
  else if (counter<0) { counter = 0; lyr.vis('hidden') }
  else timer = setTimeout(menuObj.myName+'.'+(dir>0?'show':'hide')+'Menu("'+menuName+'")', 40);
 }
}

function addMenuBorder(mObj, iS, alpha, bordCol, bordW, backCol, backW)
{
 for (var mN in mObj.menu)
 {
  var mR=mObj.menu[mN], dS='<div style="position:absolute; background:';
  if (mR[0].itemSty != iS) continue;
  for (var mI=1; mI<mR.length; mI++)
  {
   mR[mI].iX += bordW+backW;
   mR[mI].iY += bordW+backW;
  }
  mW = mR[0].menuW += 2*(bordW+backW);
  mH = mR[0].menuH += 2*(bordW+backW);

  if (isNS4) mR[0].extraHTML += '<layer bgcolor="'+bordCol+'" left="0" top="0" width="'+mW+
   '" height="'+mH+'" z-index="980"><layer bgcolor="'+backCol+'" left="'+bordW+'" top="'+
   bordW+'" width="'+(mW-2*bordW)+'" height="'+(mH-2*bordW)+'" z-index="990"></layer></layer>';
  else mR[0].extraHTML += dS+bordCol+'; left:0px; top:0px; width:'+mW+'px; height:'+mH+
   'px; z-index:980; '+(alpha!=null?'filter:alpha(opacity='+alpha+'); -moz-opacity:'+(alpha/100):'')+
   '">'+dS+backCol+'; left:'+bordW+'px; top:'+bordW+'px; width:'+(mW-2*bordW)+'px; height:'+
   (mH-2*bordW)+'px; z-index:990"></div></div>';
 }
}

function addDropShadow(mObj, iS)
{
 for (var mN in mObj.menu)
 {
  var a=arguments, mD=mObj.menu[mN][0], addW=addH=0;
  if (mD.itemSty != iS) continue;
  for (var shad=2; shad<a.length; shad++)
  {
   var s = a[shad];
   if (isNS4) mD.extraHTML += '<layer bgcolor="'+s[1]+'" left="'+s[2]+'" top="'+s[3]+'" width="'+
    (mD.menuW+s[4])+'" height="'+(mD.menuH+s[5])+'" z-index="'+(arguments.length-shad)+'"></layer>';
   else mD.extraHTML += '<div style="position:absolute; background:'+s[1]+'; left:'+s[2]+
    'px; top:'+s[3]+'px; width:'+(mD.menuW+s[4])+'px; height:'+(mD.menuH+s[5])+'px; z-index:'+
    (a.length-shad)+'; '+(s[0]!=null?'filter:alpha(opacity='+s[0]+'); -moz-opacity:'+(s[0]/100):'')+
    '"></div>';
   addW=Math.max(addW, s[2]+s[4]);
   addH=Math.max(addH, s[3]+s[5]);
  }
  mD.menuW+=addW; mD.menuH+=addH;
 }
}