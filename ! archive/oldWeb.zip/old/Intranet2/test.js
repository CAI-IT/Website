if (!((ScriptEngineMajorVersion() >= 5) && (ScriptEngineMinorVersion() >= 5)))
WScript.Echo("Script Engine v5.5 is required.\nCurrent version is : " + ScriptEngineMajorVersion() + "." + ScriptEngineMinorVersion());
else
WScript.Echo("Current version is : " + ScriptEngineMajorVersion() + "." + ScriptEngineMinorVersion());