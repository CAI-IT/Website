function OnButton1()
{
	document.evaluationSelect.action = "jobEvaluationForm1.asp"
	var checkForm
	checkForm = validateForm();
	if (checkForm == true)
	{
		document.evaluationSelect.submit();
		return true;			// Submit the page
	}
	else
	{
		return false;
	}
	
}

function OnButton2()
{
	document.evaluationSelect.action = "jobEvaluationCreateSelf.asp"
	var checkForm
	checkForm = validateForm();
	if (checkForm == true)
	{
		document.evaluationSelect.submit();
		return true;			// Submit the page
	}
	else
	{
		return false;
	}
	
}

function validateForm()
{
 	//Validate the Evaluation Date from the form
	var dateStr = document.evaluationSelect.evalDate.value;
    var datePat = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;
    var matchArray = dateStr.match(datePat); // is the format ok?

    if (matchArray == null) {
        alert("Please enter Evaluation date as either mm/dd/yyyy or mm-dd-yyyy.");
		document.evaluationSelect.evalDate.focus();
        return false;
    }

    month = matchArray[1]; // parse date into variables
    day = matchArray[3];
    year = matchArray[5];

    if (month < 1 || month > 12) { // check month range
        alert("Month must be between 1 and 12.");
		document.evaluationSelect.evalDate.focus();
        return false;
    }

    if (day < 1 || day > 31) {
        alert("Day must be between 1 and 31.");
		document.evaluationSelect.evalDate.focus();
        return false;
    }

    if ((month==4 || month==6 || month==9 || month==11) && day==31) {
        alert("Month "+month+" doesn't have 31 days!");
		document.evaluationSelect.evalDate.focus();
        return false;
    }

    if (month == 2) { // check for february 29th
        var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
        if (day > 29 || (day==29 && !isleap)) {
            alert("February " + year + " doesn't have " + day + " days!");
			document.evaluationSelect.evalDate.focus();
            return false;
        }
    }
 
 	//Validate the Evaluation Start Period from the form	
	var dateStr = document.evaluationSelect.periodStart.value;
    var datePat = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;
    var matchArray = dateStr.match(datePat); // is the format ok?

    if (matchArray == null) {
        alert("Please enter evaluation starting date as either mm/dd/yyyy or mm-dd-yyyy.");
		document.evaluationSelect.periodStart.focus();
        return false;
    }

    month = matchArray[1]; // parse date into variables
    day = matchArray[3];
    year = matchArray[5];

    if (month < 1 || month > 12) { // check month range
        alert("Month must be between 1 and 12.");
		document.evaluationSelect.periodStart.focus();
        return false;
    }

    if (day < 1 || day > 31) {
        alert("Day must be between 1 and 31.");
		document.evaluationSelect.periodStart.focus();
        return false;
    }

    if ((month==4 || month==6 || month==9 || month==11) && day==31) {
        alert("Month "+month+" doesn't have 31 days!");
		document.evaluationSelect.periodStart.focus();
        return false;
    }

    if (month == 2) { // check for february 29th
        var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
        if (day > 29 || (day==29 && !isleap)) {
            alert("February " + year + " doesn't have " + day + " days!");
			document.evaluationSelect.periodStart.focus();
            return false;
        }
    }
 	
 	//Validate the Evaluation End Period from the form	
	var dateStr = document.evaluationSelect.periodEnd.value;
    var datePat = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;
    var matchArray = dateStr.match(datePat); // is the format ok?

    if (matchArray == null) {
        alert("Please enter evaluation ending date as either mm/dd/yyyy or mm-dd-yyyy.");
		document.evaluationSelect.periodEnd.focus();
        return false;
    }

    month = matchArray[1]; // parse date into variables
    day = matchArray[3];
    year = matchArray[5];

    if (month < 1 || month > 12) { // check month range
        alert("Month must be between 1 and 12.");
		document.evaluationSelect.periodEnd.focus();		
        return false;
    }

    if (day < 1 || day > 31) {
        alert("Day must be between 1 and 31.");
		document.evaluationSelect.periodEnd.focus();
        return false;
    }

    if ((month==4 || month==6 || month==9 || month==11) && day==31) {
        alert("Month "+month+" doesn't have 31 days!");
		document.evaluationSelect.periodEnd.focus();
        return false;
    }

    if (month == 2) { // check for february 29th
        var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
        if (day > 29 || (day==29 && !isleap)) {
            alert("February " + year + " doesn't have " + day + " days!");
			document.evaluationSelect.periodEnd.focus();
            return false;
        }
    }
    return true; // date is valid	
}
