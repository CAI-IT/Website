<script language="javascript">


//  *****************************************
//  the following creates an error tracking class
//    2 data members: foundError and errMsg
//	  2 member functions:  addError( -message-) and displayErrors()

function classError()
{
  this.foundError = false;
  this.errMsg = "The following errors were found:\n"

  this.add = ErrorAddError;
  this.displayErrors = ErrorDisplayErrors;
}

function ErrorAddError( newError)
{
  this.errMsg = this.errMsg + "\n" + newError;
  this.foundError = true;
}

function ErrorDisplayErrors()
{
  alert( this.errMsg);
  return;
}
// ******** end classError ******************
function isFieldBlank(theField)
{
	if (isEmpty(theField.value))
		return true;
	else
		return false;
}

function isFieldBlank2(theField)
{
	if (stripInitialWhitespace(theField.value) == '')
		return true;
	else
		return false;
}//end isFieldBlank

function isFieldBlank3(theField)
{
	if (stripInitialWhitespace(theField.value) == '')
		return (theField.value.length > 0);
	else
		return false;
}//end isFieldBlank

// ******** begin paste from javascriptLib1
//            (this can and should be cut out and changed to include javascriptLib1.js

function makeArray(n) {
   for (var i = 1; i <= n; i++)
   {
      this[i] = 0;
   } 
   return this
} // end makeArray



var defaultEmptyOK = true;

var USStateCodes = "AL|AK|AS|AZ|AR|CA|CO|CT|DE|DC|FM|FL|GA|GU|HI|ID|IL|IN|IA|KS|KY|LA|ME|MH|MD|MA|MI|MN|MS|MO|MT|NE|NV|NH|NJ|NM|NY|NC|ND|MP|OH|OK|OR|PW|PA|PR|RI|SC|SD|TN|TX|UT|VT|VI|VA|WA|WV|WI|WY|AE|AA|AE|AE|AP"

var whitespace = " \t\n\r";

function isEmpty(s)
{   return ((s == null) || (s.length == 0))
}

function isWhitespace (s)
{   var i;
    if (isEmpty(s)) return true;
    for (i = 0; i < s.length; i++)
    {   
        var c = s.charAt(i);
        if (whitespace.indexOf(c) == -1) return false;
    }
    return true;
}

function isLetter (c)
{   return ( ((c >= "a") && (c <= "z")) || ((c >= "A") && (c <= "Z")) )
}

function isDigit (c)
{   return ((c >= "0") && (c <= "9"))
}

function isLetterOrDigit (c)
{   return (isLetter(c) || isDigit(c))
}

function isInteger (s)
{   var i;
    for (i = 0; i < s.length; i++)
    {   
        var c = s.charAt(i);
        if (!isDigit(c)) return false;
    }
    return true;
}

function isFloat (s)
{   var i;
    var seenDecimalPoint = false;
    if (s == ".") return false;
    for (i = 0; i < s.length; i++)
    {   
        var c = s.charAt(i);
        if ((c == ".") && !seenDecimalPoint) seenDecimalPoint = true;
        else if (!isDigit(c)) return false;
    }
    return true;
}

function isAlphabetic (s)
{   var i;
    for (i = 0; i < s.length; i++)
    {   
        var c = s.charAt(i);
        if (!isLetter(c))
        return false;
    }
    return true;
}

function isAlphanumeric (s)
{   var i;
    for (i = 0; i < s.length; i++)
    {   
        var c = s.charAt(i);
        if (! (isLetter(c) || isDigit(c)) )
        return false;
    }
    return true;
}

function isNumeric (s)
{   var i;
    for (i = 0; i < s.length; i++)
    {   
        var c = s.charAt(i);
        if (! isDigit(c) )
        return false;
    }
    return true;
}


function isIntegerInRange (s, a, b)
{   
    if (!isInteger(s, false)) return false;
    var num = parseInt (s);
    return ((num >= a) && (num <= b));
}

function isValidState( theField)
{
	if (theField.value.length != 2)
		return false;
	else
	{
		theField.value = theField.value.toUpperCase();
		return isStateCode( theField.value);
	}
}

function isStateCode(s)
{   
    return ( (USStateCodes.indexOf(s) != -1) &&
             (s.indexOf("|") == -1) )
}

// ********* begin character bag functions & whitespace functions *******

function charInBag(c, bag)
{               if (bag.indexOf(c) == -1) return false;
                else return true;
}

function strip1CharInBag (s, bag)
{
	var blnStripped = false;
	var returnString = "";
	var i;
	var c;
	for (i = 0; (i < s.length) && (!blnStripped); i++)
	{
		c = s.charAt(i);
		if ((bag.indexOf(c) == -1))
			returnString += c;
		else
			blnStripped = true;
	}
	for (i; i < s.length; i++)
	{
		c = s.charAt(i);
		returnString += c;
	}
	return returnString;
}	


function stripCharsInBag (s, bag)
{   var i;
    var returnString = "";
    for (i = 0; i < s.length; i++)
    {   
        var c = s.charAt(i);
        if (bag.indexOf(c) == -1) returnString += c;
    }
    return returnString;
}
function stripCharsNotInBag (s, bag)
{   var i;
    var returnString = "";
    for (i = 0; i < s.length; i++)
    {   
        var c = s.charAt(i);
        if (bag.indexOf(c) != -1) returnString += c;
    }
    return returnString;
}

function stripWhitespace (s)
{   return stripCharsInBag (s, whitespace)
}

function stripInitialWhitespace (s)
{   var i = 0;
    while ((i < s.length) && charInBag (s.charAt(i), whitespace))
       i++;
    return s.substring (i, s.length);
}

function stripEndWhitespace (s)
{
   var i = s.length - 1;
   while ((i >= 0) && charInBag (s.charAt(i), whitespace))
      i--;
   return s.substring(0, i + 1);
}

function stripEdges( theField)
{
	theField.value = stripEndWhitespace( stripInitialWhitespace( theField.value));
}

function stripEdgeWhitespace (s)
{
   return stripEndWhitespace( stripInitialWhitespace( s));
}


// ******** end charbag and whitespace functions

function isValidMoney( s)
{
	var isValid = true;
	
	s = stripCharsInBag(s, "$,");
	
	if (!isFloat(s))
		return false;
		
	if(s.length < 4)
		return false;
	
	var decLoc = s.indexOf(".");
	
	if(decLoc == 0)
		return false;
	else if(decLoc != (s.length - 3))
		return false;
	
	return isValid;
}

function formatMoney(s)
{
	var sf = s;
	sf = stripWhitespace( sf);
	sf = stripCharsInBag( sf, ",$");
	
	var decimal = "";
	var decLoc = sf.indexOf(".");
	if (decLoc > -1)
	{
		decimal = sf.substring(decLoc,sf.length);
		sf = sf.substring(0, decLoc);
	}
	
	var len = sf.length;
	var j = 0;
	var sf2 = "";
	for( i = len - 1; i >= 0; i--)
	{
		j++;
		sf2 += sf.charAt(i);
		if (((j % 3) == 0) && (i != 0))
			sf2 += ",";
	} //for
	
	sf = "$";
	len = sf2.length;
	for( i = len - 1; i >= 0; i--)
		sf += sf2.charAt(i);
		
	return (sf + decimal);
} // formatMoney

// * this is a neat little function that formats text *)
function reformat (s)
{   var arg;
    var sPos = 0;
    var resultString = "";
    for (var i = 1; i < reformat.arguments.length; i++) {
       arg = reformat.arguments[i];
       if (i % 2 == 1) resultString += arg;
       else {
           resultString += s.substring(sPos, sPos + arg);
           sPos += arg;
       }
    }
    return resultString;
}


function isValidZip (theField)
{
	var s;
	s = strip1CharInBag(theField.value, "-");
	if (isInteger(s))
	{
		if ((s.length != 5) && (s.length != 9))
			return false;
	}
	else
		return false;
	return true;
}

function isValidFour (theField)
{
	var s;
	s = strip1CharInBag(theField.value, "-");
	if (isInteger(s))
	{
		if (s.length != 4)
			return false;
	}
	else
		return false;
	return true;
}

function isValidThree (theField)
{
	var s;
	s = strip1CharInBag(theField.value, "-");
	if (isInteger(s))
	{
		if (s.length != 3)
			return false;
	}
	else
		return false;
	return true;
}

function isValidPhone (theField)
{
	var s;
	theField.value = stripCharsInBag(stripWhitespace( theField.value),"()");
	s = stripCharsInBag( theField.value, "-/");
	if (isNumeric(s))
	{
		if ((s.length != 7) && (s.length != 10) && (s.length != 11))
			return false;
	}
	else
		return false;
	return true;
}

function isValidEmail (s)
{
    if (isWhitespace(s)) return false;
    var i = 1;
    var sLength = s.length;
    while ((i < sLength) && (s.charAt(i) != "@"))
    { i++
    }
    if ((i >= sLength) || (s.charAt(i) != "@")) return false;
    else i += 2;
    while ((i < sLength) && (s.charAt(i) != "."))
    { i++
    }
    if ((i >= sLength - 1) || (s.charAt(i) != ".")) return false;
    else return true;
}

// ******** end paste from javascript lib1


// **********************************************************
// ** getSystemDate returns the current system date in the form 'mm/dd/yyyy'
// **
// ** POST: if getYear() is 98 or 99, the yyyy will equal 1998 or 1999.
// **       else, the first two digits of the yyyy will be '20'

function getSystemDate()
{
	var cDate = new Date(); 
	var cDay = cDate.getDate();
	var cMonth = cDate.getMonth();
	var cYear = cDate.getYear();
		
	if(cYear > 97)
		strYear = "19" + cYear;
	else
		strYear = "20" + cYear;

	strDay = "" + cDay;
	if(strDay.length == 1)
		strDay = "0" + strDay;

	cMonth = cMonth + 1;
	strMonth = "" + cMonth;
	if(strMonth.length == 1)
		strMonth = "0" + cMonth;

	strSysDate = strMonth + "/" + strDay + "/" + strYear;
	return strSysDate;
}


function isValidDate(field)
// mm/dd/yyyy
{
	var vDate = field.value;
	var isValid = true;

	if (vDate.length < 10)
		isValid = false;
	else
	{
	  //alert(strF + " len->" + strF.length + " <->" + strF[0] + strF[1]+ strF[2] + strF[3]+ strF[4] + strF[5]+ strF[6] + "<->" + strF.charAt(5) + strF.charAt(6));
	  isValid = (vDate.charAt(2) == '/') && (vDate.charAt(5) == '/');
	  if (isValid)
	  {
	  	var vMonth = vDate.substring(0,2);
		var vDay = vDate.substring(3,5);
		var vYear = vDate.substring(6,10);
		
		if (isInteger(vMonth) && isInteger(vDay) && isInteger(vYear))
		{
		  if (vMonth.charAt(0) == '0')
		  	isValid = isValid && (vMonth.charAt(1) != '0');
		  else
		  	isValid = isValid && (0 < parseInt(vMonth)) && ((parseInt(vMonth) < 13));

		  if (vDay.charAt(0) == '0')
		  	isValid = isValid && (vDay.charAt(1) != '0');
		  else
		  	isValid = isValid && (0 < parseInt(vDay)) && ((parseInt(vDay) < 32));

		  isValid = isValid  && (999 < parseInt(vYear));			
		}
		else
			isValid = false;
      }// if (isValid)
	}// if (vDate.length)...
	
	return isValid;
} // isValidDate

// *****************************************************
// ** isGreaterDate compares vDate1 and vDate2, returns true
// **   if vDate1 > vDate2, false if vDate1 < vDate1
// **
// ** PRE: vDate1 and vDate2 must be in the form mm/dd/yyyy;
// **      isValidDate should be called on each of these before using isGreaterDate
// **
// ** POST: returns true of false

function isGreaterDate( vDate1, vDate2)
{
	var isGreater = false;

	m1 = vDate1.substring(0,2);
	m2 = vDate2.substring(0,2);
	d1 = vDate1.substring(3,5);
	d2 = vDate2.substring(3,5);
	y1 = vDate1.substring(6,10);
	y2 = vDate2.substring(6,10);
		
	isGreater = (y1 > y2) || ((y1 == y2) && (m1 > m2)) || ((y1 == y2) && (m1 == m2) && (d1 > d2));
	
	return isGreater;
}

function isValidDate2(field)
// isValidDate2 validates a date field;
// month must be m or mm; day must be d or dd; year must be yy or yyyy
//
// returns true or false if date is valid or not
{
	var vDate = field.value;

	var isValid = true;
	var dashLocation;
	var dayLocation;
	var yearLocation;
	var vMonth = 0;
	var vDay = 0;
	var vYear = 0;

	if (vDate.length < 6)
		return false;

	dashLocation = vDate.indexOf("/");
	if ((dashLocation != 1) && (dashLocation != 2))
		return false;

	vMonth = vDate.substring(0,dashLocation);

	dayLocation = dashLocation + 1;
	dashLocation = vDate.indexOf("/", dayLocation);

	if (dashLocation == -1)
		return false;

	vDay = vDate.substring(dayLocation, dashLocation);
	if(vDay.length == 0)
		return false;

	yearLocation = dashLocation + 1;
	vYear = vDate.substring(yearLocation, vDate.length);
	if (vYear.length == 0)
		return false;
	
  //alert(vMonth + "*" + vDay + "*" + vYear);
	
	if (isInteger(vMonth) && isInteger(vDay) && isInteger(vYear))
	{
	  if ((vMonth.charAt(0) == '0') && (vMonth.length == 2))
	  	isValid = isValid && (vMonth.charAt(1) != '0');
	  else
	  	isValid = isValid && (0 < parseInt(vMonth)) && ((parseInt(vMonth) < 13));

	  if ((vDay.charAt(0) == '0') && (vDay.length == 2))
	  	isValid = isValid && (vDay.charAt(1) != '0');
	  else
	  	isValid = isValid && (0 < parseInt(vDay)) && ((parseInt(vDay) < 32));

	  isValid = isValid  && ( ((0 <= parseInt(vYear)) && (parseInt(vYear) < 100)) || (999 < parseInt(vYear)) );
	}
	else
		isValid = false;

	return isValid;
} // isValidDate2

// *****************************************************
// ** isGreaterDate2 compares vDate1 and vDate2, returns true
// **   if vDate1 > vDate2, false if vDate1 < vDate1
// **
// ** PRE: vDate1 and vDate2 must be valid dates according to isValidDate2
// **      isValidDate2 should be called on each of these before using isGreaterDate2
// **
// ** POST: returns true or false

function isGreaterDate2( vDate1, vDate2)
{
	var vDate;
	var dashLocation;
	var dayLocation;
	var yearLocation;
	var m1 = 0;
	var d1 = 0;
	var y1 = 0;
	var m2 = 0;
	var d2 = 0;
	var y2 = 0;

	vDate = vDate1;
	dashLocation = vDate.indexOf("/");

	m1 = vDate.substring(0,dashLocation);

	dayLocation = dashLocation + 1;
	dashLocation = vDate1.indexOf("/", dayLocation);

	d1 = vDate.substring(dayLocation, dashLocation);

	yearLocation = dashLocation + 1;
	y1 = vDate.substring(yearLocation, vDate.length);

	
	vDate = vDate2;
	dashLocation = vDate.indexOf("/");

	m2 = vDate.substring(0,dashLocation);

	dayLocation = dashLocation + 1;
	dashLocation = vDate.indexOf("/", dayLocation);

	d2 = vDate.substring(dayLocation, dashLocation);

	yearLocation = dashLocation + 1;
	y2 = vDate.substring(yearLocation, vDate.length);

	var isGreater = false;

	if(y1 < 100)
    {
		if (y1 > 96)
			y1 = 19 + y1; 
		else
			y1 = 20 + y1;
	}

	if(y2 < 100)
    {
		if (y2 > 96)
			y2 = 19 + y2;
		else
			y2 = 20 + y2;
	}

	isGreater = (y1 > y2) || ((y1 == y2) && (parseFloat(m1) > parseFloat(m2))) || ((y1 == y2) && (parseFloat(m1) == parseFloat(m2)) && (parseFloat(d1) > parseFloat(d2)));
	
	return isGreater;
} // isGreaterDate2


function goBackinTime()
//refresh function when meta-refresh cant be used
{	
	today = new Date();
	StartTime=today.getSeconds();
	EndTime=today.getSeconds();
	while (StartTime + 5 != EndTime)
	{
		next = new Date();
		EndTime=next.getSeconds();
	}
	history.go(-1);
}
function checkdate(evalDate)
{
	//Validate the Evaluation Date from the form
	var dateStr = evalDate.value;
    var datePat = /^(\d{1,2})(\/)(\d{1,2})(\/)(\d{4})$/;
    var matchArray = dateStr.match(datePat); // is the format ok?

    if (matchArray == null) {
        alert("Please enter the date as either mm/dd/yyyy or mm-dd-yyyy.");
        return false;
    }

    month = matchArray[1]; // parse date into variables
    day = matchArray[3];
    year = matchArray[5];

    if (month < 1 || month > 12) { // check month range
        alert("Month must be between 1 and 12.");
        return false;
    }

    if (day < 1 || day > 31) {
        alert("Day must be between 1 and 31.");
        return false;
    }

    if ((month==4 || month==6 || month==9 || month==11) && day==31) {
        alert("Month "+month+" doesn't have 31 days!");
        return false;
    }

    if (month == 2) { // check for february 29th
        var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
        if (day > 29 || (day==29 && !isleap)) {
            alert("February " + year + " doesn't have " + day + " days!");
            return false;
        }
    }
	return true
}
</script>