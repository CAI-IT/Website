

var isDOM=document.getElementById?1:0;
var isIE=document.all?1:0;
var isNS4=navigator.appName=='Netscape'&&!isDOM?1:0;
var isIE4=isIE&&!isDOM?1:0;
var isOp=window.opera?1:0;
var isDyn=isDOM||isIE||isNS4;

function getRef(id, par)
{
 par=!par?document:(par.navigator?par.document:par);
 return (isIE ? par.all[id] :
  (isDOM ? (par.getElementById?par:par.ownerDocument).getElementById(id) :
  (isNS4 ? par.layers[id] : null)));
}

function getSty(id, par)
{
 var r=getRef(id, par);
 return r?(isNS4?r:r.style):null;
}

if (!window.LayerObj) var LayerObj = new Function('id', 'par',
 'this.ref=getRef(id, par); this.sty=getSty(id, par); return this');
function getLyr(id, par) { return new LayerObj(id, par) }

function LyrFn(fn, fc)
{
 LayerObj.prototype[fn] = new Function('var a=arguments,p=a[0],px=isNS4||isOp?0:"px"; ' +
  'with (this) { '+fc+' }');
}
LyrFn('x','if (!isNaN(p)) sty.left=p+px; else return parseInt(sty.left)');
LyrFn('y','if (!isNaN(p)) sty.top=p+px; else return parseInt(sty.top)');
LyrFn('vis','sty.visibility=p');
LyrFn('bgColor','if (isNS4) sty.bgColor=p?p:null; ' +
 'else sty.background=p?p:"transparent"');
LyrFn('bgImage','if (isNS4) sty.background.src=p?p:null; ' +
 'else sty.background=p?"url("+p+")":"transparent"');
LyrFn('clip','if (isNS4) with(sty.clip){left=a[0];top=a[1];right=a[2];bottom=a[3]} ' +
 'else sty.clip="rect("+a[1]+"px "+a[2]+"px "+a[3]+"px "+a[0]+"px)" ');
LyrFn('write','if (isNS4) with (ref.document){write(p);close()} else ref.innerHTML=p');
LyrFn('alpha','var f=ref.filters,d=(p==null); if (f) {' +
 'if (!d&&sty.filter.indexOf("alpha")==-1) sty.filter+=" alpha(opacity="+p+")"; ' +
 'else if (f.length&&f.alpha) with(f.alpha){if(d)enabled=false;else{opacity=p;enabled=true}} }' +
 'else if (isDOM) sty.MozOpacity=d?"":p+"%"');

function setLyr(lVis, docW, par)
{
 if (!setLyr.seq) setLyr.seq=0;
 if (!docW) docW=0;
 var obj = (!par ? (isNS4 ? window : document.body) :
  (!isNS4 && par.navigator ? par.document.body : par));
 var oIA=obj.insertAdjacentHTML, oAC=obj.appendChild, newID='_js_layer_'+setLyr.seq++;

 if (oIA) oIA('beforeEnd', '<div id="'+newID+'" style="position:absolute"></div>');
 else if (oAC)
 {
  var newL=document.createElement('div');
  oAC(newL); newL.id=newID; newL.style.position='absolute';
 }
 else if (isNS4)
 {
  var newL=new Layer(docW, obj);
  newID=newL.id;
 }

 var lObj=getLyr(newID, par);
 with (lObj) if (ref) { vis(lVis); x(0); y(0); sty.width=docW+(isNS4?0:'px') }
 return lObj;
}

var CSSmode=document.compatMode;
CSSmode=(CSSmode&&CSSmode.indexOf('CSS')!=-1)||isDOM&&!isIE||isOp?1:0;

if (!window.page) var page = { win: window, minW: 0, minH: 0, MS: isIE&&!isOp,
 db: CSSmode?'documentElement':'body' }

page.winW=function()
 { with (this) return Math.max(minW, MS?win.document[db].clientWidth:win.innerWidth) }
page.winH=function()
 { with (this) return Math.max(minH, MS?win.document[db].clientHeight:win.innerHeight) }

page.scrollX=function()
 { with (this) return MS?win.document[db].scrollLeft:win.pageXOffset }
page.scrollY=function()
 { with (this) return MS?win.document[db].scrollTop:win.pageYOffset }

function popOver(mN, iN) { with (this)
{
 clearTimeout(hideTimer);
 overM = mN;
 overI = iN;
 if (iN && this.onmouseover) onmouseover(mN, iN);

 litOld = litNow;
 litNow = new Array();
 var litM = mN, litI = iN;
 while(1)
 {
  litNow[litM] = litI;
  if (litM == 'root') break;
  litI = menu[litM][0].parentItem;
  litM = menu[litM][0].parentMenu;
 }

 var same = true;
 for (var z in menu) if (litNow[z] != litOld[z]) same = false;
 if (same) return;

 clearTimeout(showTimer);

 for (thisM in menu) with (menu[thisM][0])
 {
  if (!lyr) continue;

  litI = litNow[thisM];
  oldI = litOld[thisM];

  if (litI && (litI != oldI)) changeCol(thisM, litI, true);

  if (oldI && (oldI != litI)) changeCol(thisM, oldI, false);

  if (litI && !visNow && (thisM != 'root'))
  {
   showMenu(thisM);
   visNow = true;
  }

  if (isNaN(litI) && visNow)
  {
   hideMenu(thisM);
   visNow = false;
  }
 }

 nextMenu = '';
 if ((menu[mN][iN].type == 'sm:') && !menu[mN][0].subsOnClick)
 {
  var targ = menu[mN][iN].href, lyrM = menu[mN][0].lyr;

  var showStr = 'with ('+myName+') { menu.'+targ+'[0].visNow = true; ' +
   'position("'+targ+'"); showMenu("'+targ+'") }';
  nextMenu = targ;
  if (showDelay) showTimer = setTimeout(showStr, showDelay);
  else eval(showStr);
 }
}}

function popOut(mN, iN) { with (this)
{
 if ((mN != overM) || (iN != overI)) return;

 if (this.onmouseout) onmouseout(mN, iN);

 var thisI = menu[mN][iN];

 if (thisI.href != nextMenu)
 {
  clearTimeout(showTimer);
  nextMenu = '';
 }

 if (hideDelay)
 {
  var delay = ((mN == 'root') && (thisI.type != 'sm:')) ? 50 : hideDelay;
  hideTimer = setTimeout(myName + '.over("root", 0)', delay);
 }

 overM = 'root';
 overI = 0;
}}

function popClick(mN, iN) { with (this)
{
 if (this.onclick) onclick(mN, iN);

 var thisI = menu[mN][iN], hideM = true;

 with (thisI) switch (type)
 {
  case 'sm:':
  {
   if (menu[overM][0].subsOnClick)
   {
    menu[href][0].visNow = true;
    position(href);
    showMenu(href);
    hideM = false;
   }
   break;
  }
  case 'js:': { eval(href); break }
  case '': type = 'window';
  default: if (href) eval(type + '.location.href = "' + href + '"');
 }

 if (hideM) over('root', 0);
}}

function popChangeCol(mN, iN, isOver) { with (this.menu[mN][iN])
{
 if (!lyr || !lyr.ref) return;

 var col = isOver?overCol:outCol;
 var bgFn = (col.indexOf('.')==-1) ? 'bgColor' : 'bgImage';
 if (isNS4) lyr[bgFn](col);

 if ((overClass != outClass) || (outBorder != overBorder)) with (lyr)
 {
  if (isNS4) write(this.getHTML(mN, iN, isOver));
  else
  {
   ref.className = (isOver ? overBorder : outBorder);
   var chl = (isDOM ? ref.childNodes : ref.children)
   if (chl) for (var i = 0; i < chl.length; i++) chl[i].className = isOver?overClass:outClass;
  }
 }

 if (!isNS4) lyr[bgFn](col);

 if (outAlpha != overAlpha) lyr.alpha(isOver ? overAlpha : outAlpha);
}}

function popPosition(posMN) { with (this)
{
 for (mN in menu)
 {
  if (posMN && (posMN != mN)) continue;
  with (menu[mN][0])
  {
   if (!lyr || !lyr.ref || !visNow) continue;

   var pM, pI, newX = eval(offX), newY = eval(offY);
   if (mN != 'root')
   {
    pM = menu[parentMenu];
    pI = pM[parentItem].lyr;
    if (!pI) continue;
   }

   var eP = eval(par);
   var pW = (eP && eP.navigator ? eP : window);

   with (pW.page) var sX=scrollX(), wX=sX+winW(), sY=scrollY(), wY=winH()+sY;
   wX = isNaN(wX)||!wX ? 9999 : wX;
   wY = isNaN(wY)||!wY ? 9999 : wY;

   if (pM && typeof(offX)=='number') newX = Math.max(sX,
    Math.min(newX+pM[0].lyr.x()+pI.x(), wX-menuW-(isIE?5:20)));
   if (pM && typeof(offY)=='number') newY = Math.max(sY,
    Math.min(newY+pM[0].lyr.y()+pI.y(), wY-menuH-(isIE?5:20)));

   lyr.x(newX);
   lyr.y(newY);
  }
 }
}}

function addProps(obj, data, names, addNull)
{
 for (var i = 0; i < names.length; i++) if(i < data.length || addNull) obj[names[i]] = data[i];
}

function ItemStyle()
{
 var names = ['len', 'spacing', 'popInd', 'popPos', 'pad', 'outCol', 'overCol', 'outClass',
  'overClass', 'outBorder', 'overBorder', 'outAlpha', 'overAlpha', 'normCursor', 'nullCursor'];
 addProps(this, arguments, names, true);
}

function popStartMenu(mName) { with (this)
{
 if (!menu[mName]) { menu[mName] = new Array(); menu[mName][0] = new Object(); }

 actMenu = menu[mName];
 aM = actMenu[0];
 actMenu.length = 1;

 var names = ['isVert', 'isVert', 'offX','offY', 'width', 'itemSty', 'par',
  'parentMenu', 'parentItem', 'visNow', 'oncreate', 'subsOnClick'];
 addProps(aM, arguments, names, true);

 aM.extraHTML = '';
 aM.menuW = aM.menuH = 0;

 if (!aM.lyr) aM.lyr = null;

 if (mName == 'root') menu.root[0].oncreate = new Function('this.visNow=true; ' +
  myName + '.position("root"); this.lyr.vis("visible")');
}}

function popAddItem() { with (this) with (actMenu[0])
{
 var aI = actMenu[actMenu.length] = new Object();

 var names = ['text', 'href', 'type', 'itemSty', 'len', 'spacing', 'popInd', 'popPos',
  'pad', 'outCol', 'overCol', 'outClass', 'overClass', 'outBorder', 'overBorder',
  'outAlpha', 'overAlpha', 'normCursor', 'nullCursor',
  'iX', 'iY', 'iW', 'iH', 'lyr'];
 addProps(aI, arguments, names, true);

 var iSty = (arguments[3] ? arguments[3] : actMenu[0].itemSty);
 for (prop in iSty) if (aI[prop]+'' == 'undefined') aI[prop] = iSty[prop];

 if (aI.outBorder)
 {
  if (isNS4) aI.pad++;
 }

 aI.iW = (isVert ? width : aI.len);
 aI.iH = (isVert ? aI.len : width);

 var lastGap = (actMenu.length > 2) ? actMenu[actMenu.length - 2].spacing : 0;

 var spc = ((actMenu.length > 2) && aI.outBorder ? 1 : 0);

 if (isVert)
 {
  menuH += lastGap - spc;
  aI.iX = 0; aI.iY = menuH;
  menuW = width; menuH += aI.iH;
 }
 else
 {
  menuW += lastGap - spc;
  aI.iX = menuW; aI.iY = 0;
  menuW += aI.iW; menuH = width;
 }

 if (aI.outBorder && CSSmode)
 {
  aI.iW -= 2;
  aI.iH -= 2;
 }
}}

function popGetHTML(mN, iN, isOver) { with (this)
{
 var itemStr = '';
 with (menu[mN][iN])
 {
  var textClass = (isOver ? overClass : outClass);

  if ((type == 'sm:') && popInd)
  {
   if (isNS4) itemStr += '<layer class="' + textClass + '" left="'+ ((popPos+iW)%iW) +
    '" top="' + pad + '" height="' + (iH-2*pad) + '">' + popInd + '</layer>';
   else itemStr += '<div class="' + textClass + '" style="position: absolute; left: ' +
    ((popPos+iW)%iW) + 'px; top: ' + pad + 'px; height: ' + (iH-2*pad) + 'px">' + popInd + '</div>';
  }

  if (isNS4) itemStr += (outBorder ? '<span class="' + (isOver?overBorder:outBorder) +
   '"><spacer type="block" width="' + (iW-8) + '" height="' + (iH-8) + '"></span>' : '') +
   '<layer left="' + pad + '" top="' + pad + '" width="' + (iW-2*pad) + '" height="' +
   (iH-2*pad) + '"><a class="' + textClass + '" href="#" ' +
   'onClick="return false" onMouseOver="status=\'\'; ' + myName + '.over(\'' + mN + '\',' +
   iN + '); return true">' + text + '</a></layer>';

  else itemStr += '<div class="' + textClass + '" style="position: absolute; left: ' + pad +
   'px; top: ' + pad + 'px; width: ' + (iW-2*pad) + 'px; height: ' + (iH-2*pad) + 'px">' +
   text + '</div>';
 }
 return itemStr;
}}

function popUpdate(docWrite, upMN) { with (this)
{
 if (!isDyn) return;

 for (mN in menu) with (menu[mN][0])
 {
  if (upMN && (upMN != mN)) continue;

  var str = '';

  for (var iN = 1; iN < menu[mN].length; iN++) with (menu[mN][iN])
  {
   var itemID = myName + '_' + mN + '_' + iN;

   var targM = menu[href];
   if (targM && (type == 'sm:'))
   {
    targM[0].parentMenu = mN;
    targM[0].parentItem = iN;
   }

   var isImg = (outCol.indexOf('.') != -1) ? true : false;

   if (!isIE && normCursor=='hand') normCursor = 'pointer';

   if (isDOM || isIE4)
   {
    str += '<div id="' + itemID + '" ' + (outBorder ? 'class="'+outBorder+'" ' : '') +
     'style="position: absolute; left: ' + iX + 'px; top: ' + iY + 'px; width: ' + iW +
     'px; height: ' + iH + 'px; z-index: 1000; background: ' + (isImg?'url('+outCol+')':outCol) +
     ((typeof(outAlpha)=='number') ? '; filter: alpha(opacity='+ outAlpha + '); -moz-opacity: ' +
      (outAlpha/100) : '') +
     '; cursor: ' + ((type!='sm:' && href) ? normCursor : nullCursor) + '" ';
   }
   else if (isNS4)
   {
    str += '<layer id="' + itemID + '" left="' + iX + '" top="' + iY + '" width="' +
     iW + '" height="' + iH + '" z-index="1000" ' +
     (outCol ? (isImg ? 'background="' : 'bgcolor="') + outCol + '" ' : '');
   }

   var evtMN = '(\'' + mN + '\',' + iN + ')"';
   str += 'onMouseOver="' + myName + '.over' + evtMN +
     ' onMouseOut="' + myName + '.out' + evtMN +
     ' onClick="' + myName + '.click' + evtMN + '>' +
     getHTML(mN, iN, false) + (isNS4 ? '</layer>' : '</div>');

  }

  var eP = eval(par);

  setTimeout(myName + '.setupRef(' + docWrite + ', "' + mN + '")', 50);

  var mVis = visNow ? 'visible' : 'hidden';

  if (docWrite)
  {
   var targFr = (eP && eP.navigator ? eP : window);
   targFr.document.write('<div id="' + myName + '_' + mN + '_Div" style="position: absolute; ' +
    'visibility: ' + mVis + '; left: 0px; top: 0px; width: ' + (menuW+2) + 'px; height: ' +
    (menuH+2) + 'px; z-index: 1000">' + str + extraHTML + '</div>');
  }
  else
  {
   if (!lyr || !lyr.ref) lyr = setLyr(mVis, menuW, eP);
   else if (isIE4) setTimeout(myName + '.menu.' + mN + '[0].lyr.sty.width=' + (menuW+2), 50);

   with (lyr) { sty.zIndex = 1000; write(str + extraHTML) }
  }

 }
}}

function popSetupRef(docWrite, mN) { with (this) with (menu[mN][0])
{
 if (docWrite || !lyr || !lyr.ref) lyr = getLyr(myName + '_' + mN + '_Div', eval(par));

 for (var i = 1; i < menu[mN].length; i++)
  menu[mN][i].lyr = getLyr(myName + '_' + mN + '_' + i, (isNS4?lyr.ref:eval(par)));

 if (menu[mN][0].oncreate) oncreate();
}}

function PopupMenu(myName)
{
 this.myName = myName;

 this.showTimer = 0;
 this.hideTimer = 0;
 this.showDelay = 0;
 this.hideDelay = 500;
 this.showMenu = '';

 this.menu =  new Array();
 this.litNow = new Array();
 this.litOld = new Array();

 this.overM = 'root';
 this.overI = 0;

 this.actMenu = null;

 this.over = popOver;
 this.out = popOut;
 this.changeCol = popChangeCol;
 this.position = popPosition;
 this.click = popClick;
 this.startMenu = popStartMenu;
 this.addItem = popAddItem;
 this.getHTML = popGetHTML;
 this.update = popUpdate;
 this.setupRef = popSetupRef;

 this.showMenu = new Function('mName', 'this.menu[mName][0].lyr.vis("visible")');
 this.hideMenu = new Function('mName', 'this.menu[mName][0].lyr.vis("hidden")');
}








// *** START EDITING HERE ***

var hBar = new ItemStyle(40, 10, '', 0, 0, '#336699', '#6699CC', 'highText', 'highText', 'itemBorder', '',
 null, null, 'hand', 'default');

var subM = new ItemStyle(22, 0, '&gt;', -15, 3, '#CCCCDD', '#6699CC', 'lowText', 'highText',
 'itemBorder', 'itemBorder', null, null, 'hand', 'default');

var subBlank = new ItemStyle(22, 1, '&gt;', -15, 3, '#CCCCDD', '#6699CC', 'lowText', 'highText',
 'itemBorderBlank', 'itemBorder', null, null, 'hand', 'default');

var button = new ItemStyle(22, 1, '&gt;', -15, 2, '#006633', '#CC6600', 'buttonText', 'buttonHover',
 'buttonBorder', 'buttonBorderOver', 80, 95, 'crosshair', 'default');




var pMenu = new PopupMenu('pMenu');
with (pMenu)
{

//The following variable defines a default window for use in a window.open script
//Syntax:  window.open("hyperlink", "Title(Optional)", defWindow)
var screenWidth = screen.width
var screenHeight = screen.height

w = screen.width;
h = screen.height;
aw = w - 8;
ah = h - 150;

if (screenWidth > 1000 )
{
     var defWindow="status=yes,scrollbars=yes,resizable=yes,toolbar=yes, menubar=yes, height=570,width=1010,left=0,top=0";
     //var defWindow2="maximize=yes',status=yes,scrollbars=yes,resizable=yes,toolbar=no, menubar=yes, height=570,width=1010,left=0,top=0";
     
}
else
{
     var defWindow="status=yes,scrollbars=yes,resizable=yes,toolbar=yes, menubar=yes, height=480,width=700,left=80,top=80";
     
}
     var defWindow2="maximize=yes',status=yes,scrollbars=yes,resizable=yes,toolbar=no, menubar=yes,width=" + aw + ",height= " + ah + ",left=0,top=0";
var folderWindow="scrollbars=yes,resizable=yes,menubar=yes, height=400,width=700,left=80,top=80";

// Begin ROOT Menu
//

var popOutWidth



	


popOutWidth = 90
startMenu('root', true, 0, 0, 85, hBar, 'topFr');


addItem('&nbsp Current News', 'news.asp', 'top', hBar, 20);
addItem('&nbsp Home', 'index.asp', 'botFr', hBar, 20);
addItem('&nbsp Our Mission', 'missionstatement.asp', 'botFr', hBar, 20);
addItem('&nbsp Services&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp   >', 'mProjects','sm:', hBar, 20);
addItem('&nbsp Links&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp  >', 'mLinks', 'sm:',  hBar, 20);
addItem('&nbsp Job Postings', 'JobPostings.asp', 'top', hBar, 20);
addItem('&nbspAnnual Report', 'mAnnualReport', 'sm:', hBar, 20);
//addItem('&nbsp Pictures&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp   >', 'mPictures', 'sm:', hBar, 20);
addItem('&nbsp Tech Center', 'techcenter.asp', 'botFr', hBar, 20);
addItem('&nbsp Emergencies', 'emergencies.asp', 'botFr', hBar, 20);
addItem('&nbsp Locations', 'locations.asp', 'botFr', hBar, 20);
addItem('&nbsp Contact us', 'location="mailto:webmaster@jccap.org?subject=Contact%20Link"', 'js:', hBar, 20);
addItem('&nbsp Downloads', 'ftp://www.jccap.org', 'top', hBar, 20);
addItem('&nbsp Check Mail', 'https://mail.jccap.org/exchange', 'top', hBar, 20);
addItem('&nbsp Intranet', 'window.open("https://www.jccap.org/Intranet/", "", defWindow)', 'js:', hBar, 20);
//
//End ROOT Menu

//Begin Company Information Menu
//


//Projects Sub Menu
startMenu('mProjects', true, 'botFr.page.scrollX()+1', 'botFr.page.scrollY()+77',220, subM, 'botFr');
addItem('Adult Education', 'AdultEducation.asp', 'botFr');
addItem('Case Management', 'CaseManagement.asp', 'botFr');
addItem('Child Care Information Services', 'ccis.asp', 'botFr');
addItem('Domestic Violence Prevention Services', 'CrossRoads.asp', 'botFr');
//addItem('Domestic Violence Prevention Services', 'Construction.asp', 'botFr');
addItem('Emergency Food Services', 'EmergencyFood.asp', 'botFr');
addItem('Emergency Services', 'EmergencyServices.asp', 'botFr');
addItem('Employability Skills Training Program', 'Employability.asp', 'botFr');
addItem('Homeless Services', 'Homeless.asp', 'botFr');
addItem('Housing', 'housing.asp', 'botFr');
//addItem('Information and Referral', 'iandr.asp', 'botFr');
addItem('Information and Referral', 'Construction.asp', 'botFr');
addItem('Information Technology Services', 'techservices.asp', 'botFr');
addItem('Medical Assistance Transportation Program', 'matp.asp', 'botFr');
addItem('Quality Child Care Project', 'QualityProject.asp', 'botFr');
addItem('Senior Corps Volunteer Program', 'SeniorCorps.asp', 'botFr');
addItem('Weatherization & Energy Education', 'Weatherization.asp', 'botFr');

//QCCP submenu
//startMenu('mQCCP', true, 'botFr.page.scrollX()+222', 'botFr.page.scrollY()+339', 200, subM, 'botFr');
//addItem('Jefferson County Brochure', 'window.open("http://www.jccap.org/newer/CCRD/Jefferson_Brochure.pdf", "", defWindow)', 'js:');
//addItem('Clarion County Brochure', 'window.open("http://www.jccap.org/newer/CCRD/Clarion_Brochure.pdf", "", defWindow)', 'js:');

//Annual Report Sub Menu
startMenu('mAnnualReport', true, 'botFr.page.scrollX()+1', 'botFr.page.scrollY()+174',200, subM, 'botFr');
addItem('2001 - 2002 Annual Report', 'window.open("Company_Documents/2002annualReport.pdf","", defWindow)', 'js:');

//Links
startMenu('mLinks', true, 'botFr.page.scrollX()+1', 'botFr.page.scrollY()+116', 200, subM, 'botFr');
addItem('Community Action Links', 'mCommlinks', 'sm:');
addItem('Clarion County Government Link', 'location("http://www.co.clarion.pa.us")', 'js:');
addItem('Employment and Training Links', 'mEmploymentLinks', 'sm:');
addItem('Local Links', 'mLocalLinks', 'sm:');
addItem('Search Engines', 'mSearchEngines', 'sm:');

startMenu('mEmploymentLinks', true, 'botFr.page.scrollX()+202', 'botFr.page.scrollY()+158', 241, subM, 'botFr');
addItem('Americas Job Bank', 'location("http://www.ajb.dni.us/")', 'js:');
addItem('American Universities', 'location("http://www.clas.ufl.edu/CLAS/american-universities.html")', 'js:');
addItem('Career Magazine', 'location("http://www.careermag.com/")', 'js:');
addItem('Career Mosaic', 'location("http://www.careermosaic.com")', 'js:');
addItem('Educational Testing Service', 'location("http://www.ets.org")', 'js:');
addItem('USA Jobs', 'location("http://www.usajobs.opm.gov/a.htm")', 'js:');
addItem('Job Web', 'location("http://www.jobweb.org")', 'js:');
addItem('The Monster Board', 'location("http://www.mosterboard.com")', 'js:');
addItem('Vista Online', 'location("http://altavista.worklife.com")', 'js:');
addItem('ExPan', 'location("http://cbweb9p.collegeboard.org/career/bin/career.pl")', 'js:');
addItem('Mapping Your Future', 'location("http://mapping-your-future.org")', 'js:');
addItem('Occupational Outlook', 'location("http://www.bls.gov/oco/")', 'js:');
addItem('Job Options', 'location("http://www.joboptions.com/esp/plsql/espan_enter.espan_home")', 'js:');
addItem('Entry Level Job Seeker Assistance', 'location("http://galaxy.einet.net/galaxy/Business-and-Commerce/Career-and-Employment.htm")', 'js:');
addItem('North Central Workforce Investment Board', 'location("http://www.ncwib.org")', 'js:');
addItem('Northwest Workforce Investment Board', 'location("http://www.nwpawib.org")', 'js:');

startMenu('mCommlinks', true, 'botFr.page.scrollX()+202', 'botFr.page.scrollY()+116', 300, subM, 'botFr');
addItem('Greater Erie Community Action Committee', 'location("http://www.gecac.org")', 'js:');
addItem('Community Action Partnership', 'location("http://www.communityactionpartnership.com")', 'js:');
addItem('National Community Action Foundation', 'location("http://www.ncaf.org")', 'js:');
addItem('Community Assets PA', 'mCAPAlinks', 'sm:');
addItem('Jefferson County Community Resource Directory', 'location("http://www.alltel.net/~jchs28/index.html")', 'js:');
addItem('Community Action Association of Pennsylvania', 'location("http://www.thecaap.org")', 'js:');
addItem('Community Action Program of Lancaster County', 'location("http://www.caplanc.org")', 'js:');

startMenu('mCAPAlinks', true, 'botFr.page.scrollX()+503', 'botFr.page.scrollY()+179', 180, subM, 'botFr');
addItem('Community Assets PA', 'location("http://www.communityassetspa.org/CAP/")', 'js:');
addItem('CAPA Pamphlet', 'window.open("CAPA_Pamphlet.pdf", "", defWindow)', 'js:');
//addItem('CAPA Pamphlet', 'CAPA_Publication.pdf', 'botFr'); 

//Pictures
//startMenu('mPictures', true, 'botFr.page.scrollX()+1', 'botFr.page.scrollY()+173', 200, subM, 'botFr');
//addItem('Board Pictures',  'm2002BoardPics', 'sm:');
//addItem('Going Away Luncheon for Sam', 'window.open("http://www.jccap.org/Newer/AgencyPictures/Going Away Lucheon for Sam 03-10-2003/index.htm", "", defWindow)', 'js:');

//startMenu('m2002BoardPics', true, 'botFr.page.scrollX()+202', 'botFr.page.scrollY()+173', 200, subM, 'botFr');
//addItem('2002 Board Pictures', 'window.open("http://www.jccap.org/newer/AgencyPictures/Board Pictures 09-19-02/index.htm", "", defWindow)', 'js:');

//'location("http://www.bls.gov/oco/")'
//End Company Information Menu

//Local Links
startMenu('mLocalLinks', true, 'botFr.page.scrollX()+202', 'botFr.page.scrollY()+179', 200, subM, 'botFr');
addItem('Clarion County', 'location("http://www.co.clarion.pa.us")', 'js:');
addItem('Pennsylvania', 'location("http://www.state.pa.us")', 'js:');
addItem('PennState Dubois', 'location("http://www.ds.psu.edu")', 'js:');
addItem('Indiana University Of Pennsylvania', 'location("http://www.iup.edu")', 'js:');
addItem('Clarion University', 'location("http://www.clarion.edu")', 'js:');
//Begin Company Documents Menu

//Search Engines
startMenu('mSearchEngines', true, 'botFr.page.scrollX()+202', 'botFr.page.scrollY()+200', 200, subM, 'botFr');
addItem('Yahoo', 'location("http://www.yahoo.com")', 'js:');
addItem('Google', 'location("http://www.google.com")', 'js:');
addItem('AltaVista', 'location("http://www.altavista.com")', 'js:');
addItem('Lycos', 'location("http://www.lycos.com")', 'js:');
addItem('WebCrawler', 'location("http://www.webcrawler.com")', 'js:');
addItem('Hotbot', 'location("http://www.hotbot.com")', 'js:');
addItem('MetaCrawler', 'location("http://www.metacrawler.com")', 'js:');
addItem('MetaGopher', 'location("http://www.metagopher.com")', 'js:');
addItem('infoseek', 'location("http://www.infoseek.com")', 'js:');
addItem('excite', 'location("http://www.excite.com")', 'js:');
addItem('DOGPILE', 'location("http://www.DOGPILE.com")', 'js:');



}



addMenuBorder(pMenu, window.subBlank,
 null, '#666666', 1, '#CCCCDD', 2);

addDropShadow(pMenu, window.subM,
 [40,"#333333",6,6,-4,-4], [40,"#666666",4,4,0,0]);
addDropShadow(pMenu, window.subBlank,
 [40,"#333333",6,6,-4,-4], [40,"#666666",4,4,0,0]);


if (!isOp && navigator.userAgent.indexOf('rv:0.')==-1)
{
 pMenu.showMenu = new Function('mN','menuAnim(this, mN, 100)');
 pMenu.hideMenu = new Function('mN','menuAnim(this, mN, -100)');
}



// There's no "events" section here now, remember that's handled by the SUBFR.JS file.




function menuAnim(menuObj, menuName, dir)
{
 var mD = menuObj.menu[menuName][0];
 if (!mD.timer) mD.timer = 0;
 if (!mD.counter) mD.counter = 0;
 with (mD)
 {
  clearTimeout(timer);
  if (!lyr || !lyr.ref) return;
  if (dir>0) lyr.vis('visible');
  lyr.sty.zIndex = 1001 + dir;

  lyr.clip(0, 0, menuW+2, (menuH+2)*Math.pow(Math.sin(Math.PI*counter/200),0.75) );
  if ((isDOM&&!isIE) && (counter>=100)) lyr.sty.clip='';

  counter += dir;
  if (counter>100) counter = 100;
  else if (counter<0) { counter = 0; lyr.vis('hidden') }
  else timer = setTimeout(menuObj.myName+'.'+(dir>0?'show':'hide')+'Menu("'+menuName+'")', 40);
 }
}

function addMenuBorder(mObj, iS, alpha, bordCol, bordW, backCol, backW)
{
 for (var mN in mObj.menu)
 {
  var mR=mObj.menu[mN], dS='<div style="position:absolute; background:';
  if (mR[0].itemSty != iS) continue;
  for (var mI=1; mI<mR.length; mI++)
  {
   mR[mI].iX += bordW+backW;
   mR[mI].iY += bordW+backW;
  }
  mW = mR[0].menuW += 2*(bordW+backW);
  mH = mR[0].menuH += 2*(bordW+backW);

  if (isNS4) mR[0].extraHTML += '<layer bgcolor="'+bordCol+'" left="0" top="0" width="'+mW+
   '" height="'+mH+'" z-index="980"><layer bgcolor="'+backCol+'" left="'+bordW+'" top="'+
   bordW+'" width="'+(mW-2*bordW)+'" height="'+(mH-2*bordW)+'" z-index="990"></layer></layer>';
  else mR[0].extraHTML += dS+bordCol+'; left:0px; top:0px; width:'+mW+'px; height:'+mH+
   'px; z-index:980; '+(alpha!=null?'filter:alpha(opacity='+alpha+'); -moz-opacity:'+(alpha/100):'')+
   '">'+dS+backCol+'; left:'+bordW+'px; top:'+bordW+'px; width:'+(mW-2*bordW)+'px; height:'+
   (mH-2*bordW)+'px; z-index:990"></div></div>';
 }
}

function addDropShadow(mObj, iS)
{
 for (var mN in mObj.menu)
 {
  var a=arguments, mD=mObj.menu[mN][0], addW=addH=0;
  if (mD.itemSty != iS) continue;
  for (var shad=2; shad<a.length; shad++)
  {
   var s = a[shad];
   if (isNS4) mD.extraHTML += '<layer bgcolor="'+s[1]+'" left="'+s[2]+'" top="'+s[3]+'" width="'+
    (mD.menuW+s[4])+'" height="'+(mD.menuH+s[5])+'" z-index="'+(arguments.length-shad)+'"></layer>';
   else mD.extraHTML += '<div style="position:absolute; background:'+s[1]+'; left:'+s[2]+
    'px; top:'+s[3]+'px; width:'+(mD.menuW+s[4])+'px; height:'+(mD.menuH+s[5])+'px; z-index:'+
    (a.length-shad)+'; '+(s[0]!=null?'filter:alpha(opacity='+s[0]+'); -moz-opacity:'+(s[0]/100):'')+
    '"></div>';
   addW=Math.max(addW, s[2]+s[4]);
   addH=Math.max(addH, s[3]+s[5]);
  }
  mD.menuW+=addW; mD.menuH+=addH;
 }
}
