vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|09 Sep 2002 17:14:32 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{41891185-62AD-4479-9FB7-CD778A7955AC}
vti_cacheddtm:TX|09 Sep 2002 17:14:32 -0000
vti_filesize:IR|1527
vti_backlinkinfo:VX|
