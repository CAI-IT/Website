Web ROMA system installation instruction:

Notice: The ROMA system requires MS SQL Server to store the database.

1) For Windows 2000 users:
    * You have to install Internet Information Services(IIS) 5.0 on your server.
    * Go to "Start/Setting/Control Panel/Add/Remove Programs"
    * Click on Add/Removes Windows Components"
    * If the check box of Internet Information Services(IIS) is checked, then you have
      IIS 5.0 installed already. If not, check the check box and click on Next to finish
      the installation process. 
   
   For Windows 95, 98 or NT workstation users:
    * You have to install Microsoft Personal Web Server(PWS), which will be in your
      Windows 98 CD under folder "Add-on".
    * Follow the installation instructions, and accept all the default setup.

2) Put folder "ROMA" into following folder C:\Inetpub\wwwroot\

3) Browse to "ROMA" folder and find ROMALink.udl file.

4) Right click on ROMALink.udl, then choose "Properties" from the pop up menu.

5) Click on "Connection" tab, and enter appropriate information for the ROMA database connection.

6) Before you access the ASP files, you have to know the name of your web server
   through Start/Setting/Network and Dial-up Connection, from Advanced menu select
   Network Indentification. The Network Identification tab will display your machine name
   under the description Full computer name.

7) Now you can access the ASP files through address http://your_computer_name/ROMA/ROMAlogin.asp
   